\
    import serial
    import serial.tools.list_ports
    from typing import Optional

    class SerialManager:
        def __init__(self):
            self.ser: Optional[serial.Serial] = None

        def list_ports(self):
            return [p.device for p in serial.tools.list_ports.comports()]

        def open(self, port: str, baudrate: int = 19200, timeout: float = 0.2):
            self.close()
            self.ser = serial.Serial(port=port, baudrate=baudrate, timeout=timeout)
            return self.ser.is_open

        def close(self):
            if self.ser and self.ser.is_open:
                try:
                    self.ser.close()
                finally:
                    self.ser = None

        def write(self, data: bytes):
            if not self.ser or not self.ser.is_open:
                raise RuntimeError("Serial not open")
            self.ser.write(data)

        def read(self, size: int = 64) -> bytes:
            if not self.ser or not self.ser.is_open:
                raise RuntimeError("Serial not open")
            return self.ser.read(size)
