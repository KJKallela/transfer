## 1.2.26 RC4 (from RC3i)
- Added JSON rig profiles & unified hard tune + SWR logging.
- Connect/Disconnect single button; Tune toggle.

## [1.2.26-RC1] – 2025-09-22
### Added
- Vertical button layout (aligned right side, stacked).
- Connect button now toggles Disconnect with state-aware label.
- Tune buttons disabled until connected; enabled upon successful connect.
- Bold, color-coded status bar (green=connected, red=disconnected, black=idle).
- Proper Setup/Connect separation.

### Fixed
- Setup dialog `.result` bug fixed (always defined; saved on Save).
- Removed unintended auto-opening of Setup window at startup.
- Safer `_log` and `rig` initialization.

### Notes
- Release Candidate build for 1.2.26.

# Changelog - ReminTune\n\n## v1.2.9 Final42g (2025-09-22)
- Fixed Tkinter compatibility: status bar now uses ttk.Style for bold font.
- Works on older Tcl/Tk versions that don't support `-font` option.
\n\n## v1.2.9 Final42f (2025-09-22)
- Fixed setup_dialog.py: corrected indentation of _on_save (moved inside GeneralSettingsDialog class).
\n\n## v1.2.9 Final42e (2025-09-22)
- Fixed civ.py: corrected indentation errors and unified is_open handling with is_open_flag property.
\n\n## v1.2.9 Final42d (2025-09-22)
- Fixed main.py: moved status bar initialization fully into __init__, outside of on_connect.
- Removed stray try-block indentation issue (SyntaxError resolved).
\n\n## v1.2.9 Final42c (2025-09-22)
- Fixed SyntaxError: moved `import tkinter.font as tkfont` to top-level of main.py.
- Status bar block now uses tkfont without inline import.
\n\n## v1.2.9 Final42b (2025-09-22)
- Fixed status bar code placement: no longer injected inside a stray try-block (fixed SyntaxError).
\n\n## v1.2.9 Final42 (2025-09-22)
- Main window: Status bar rig name is now bold for better visibility.
\n\n## v1.2.9 Final41 (2025-09-22)
- Main window: Status bar text now changes color.
  - Green when connected.
  - Red when disconnected.
\n\n## v1.2.9 Final40 (2025-09-22)
- Main window: Status bar now shows connection state (Connected / Disconnected).
- Updated CIVSession to maintain `is_open` flag for reliable status reporting.
\n\n## v1.2.9 Final39 (2025-09-22)
- Main window: Status bar now updates immediately when rig auto-detect resolves (e.g., Auto → IC-7100).
\n\n## v1.2.9 Final38 (2025-09-22)
- Main window: Status bar now also shows selected rig (Auto / IC-7100 / FT-710).
\n\n## v1.2.9 Final37 (2025-09-22)
- Main window: Added status bar at bottom showing active COM port and baudrate.
- Status updates automatically when saving settings.
\n\n## v1.2.9 Final36 (2025-09-22)
- Setup dialog: Added COM port validation.
  - If selected port is not available, shows error and prevents saving.
- Baudrate validation (from Final35) retained.
\n\n## v1.2.9 Final35 (2025-09-22)
- Setup dialog: Added validation for baudrate field.
  - Non-numeric values show error popup and fallback to 9600.
  - Out-of-range values (<300 or >2000000) show warning and fallback to 9600.


## v1.2.9 Final34 (2025-09-22)
- Setup dialog: Baudrate dropdown is now editable, allowing custom values in addition to common presets.


## v1.2.9 Final33 (2025-09-22)
- Setup dialog: COM port dropdown now shows descriptive labels (e.g., "COM6 – Silicon Labs CP2105 USB to UART Bridge (Enhanced)").
- Internally still saves plain COM port (e.g., "COM6") for compatibility.


## v1.2.9 Final32 (2025-09-22)
- Setup dialog: COM port dropdown now shows actual system ports (e.g., COM6, COM7).
- Requires `pyserial` package (`pip install pyserial`) for real port detection.


## v1.2.9 Final31 (2025-09-22)
- Setup dialog: Added "Refresh" button to reload available COM ports dynamically.


## v1.2.9 Final30 (2025-09-22)
- Setup dialog: COM port is now a dropdown listing available ports.
- Baudrate is now a dropdown with common speeds (300–921600 bps).
\n\n## v1.2.9 Final29 (2025-09-22)\n- Restored multi-rig support with new rigs.py.\n- Setup dialog includes Rig selector and Auto-detect option.\n- main.py uses selected/auto-detected rig and logs active protocol.\n- Included README, CHANGELOG, and test stubs.\n- Keeps earlier fixes.\n

## [1.2.26] - RC4d - 2025-09-24
### Added
- FT-710 Hard Tune: CW mode, 20W, SWR polling during TX, full restore.
- IC-7100 Hard Tune: TX hold ~4s, tuner engage, optional SWR log.
- Settings defaults: 'tune_power_w'=20, 'preferred_mode'='MD03' (CW).

### Changed
- Removed 'versions/' folder from package.
- Ensured civ ASCII/CI-V helpers exist where missing.

### Known
- IC-7100 SWR via CAT/CI-V may require exact polling opcodes; currently logged if unavailable.

## [1.2.26] - RC4e - 2025-09-24
### Added
- FT-710 Hard Tune: uses MT2;/RM; for SWR before/during/after tune, rounded to 0.1, logs success/failure.
- Restores original meter source (MTx), mode (MDxx), and power (PCxxx).
- IC-7100 mirrors the same flow where ASCII mapping is available.
- Setup dialog: Preferred Tune Mode (full MD list) and Tune Power (W) fields; saved to settings.

### Notes
- SWR mapping from Yaesu meter to human SWR is approximate; raw RM values are logged for reference.

## [1.2.26] - RC4f - 2025-09-24
### Added
- Floating always-visible **SWR Indicator** window (bar + numeric colors), opens at program start.
- **Periodic SWR polling** (defaults to 10s; configurable in Setup as "SWR Poll Interval (s)").
- Logs each SWR update (e.g., [SWR] 1.34 : 1).
- FT-710: functional hard tune + SWR query (RM5 parsing).

### Notes
- IC-7100 polling returns None for now (meter via CI-V to be added in the next build).

## [1.2.26] - RC4g - 2025-09-24
### Added
- **Tune Power (%)** and **Tune Mode** (CW/FM) in Setup.
- FT-710 hard tune uses configured tune power & mode and **restores original mode & power**.

### Existing
- SWR meter window with periodic polling and logging.

### Notes
- IC-7100 CI-V hard tune remains TODO; coming next.
