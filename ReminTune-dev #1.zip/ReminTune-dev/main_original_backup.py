import os, json
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from tkinter import messagebox
from swr_meter import SWRBarWindow
from typing import Optional

from civ import CIVSession
from rigs.rigs import Rig
from settings import load_settings, save_settings

APP_VER = "ReminTune v1.2.26 RC4"

class ReminTuneApp:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title(APP_VER)
        self.settings = load_settings()
        self.session: Optional[CIVSession] = None
        self.rig: Optional[Rig] = None
        self.tuner_enabled: Optional[bool] = None

        self._build_ui()
        try:
            if self._swr_win is None or not getattr(self._swr_win, 'winfo_exists', lambda:0)():
                self._swr_win = SWRBarWindow(self.root, title='SWR Indicator')
        except Exception as e:
            self._log(f'[SWR] init failed: {e}')
        self._update_status("disconnected")

    def _build_ui(self) -> None:
        top = ttk.Frame(self.root)
        top.pack(fill="x", padx=10, pady=8)

        self.connect_btn = ttk.Button(top, text="Connect", command=self.on_connect_toggle)
        self.connect_btn.pack(side="left")

        ttk.Button(top, text="Setup…", command=self._open_setup).pack(side="left", padx=6)

        self.btn_toggle = ttk.Button(top, text="Tune On", command=self._on_tuner_toggle, state="disabled")
        self.btn_toggle.pack(side="left", padx=6)

        self.btn_hard = ttk.Button(top, text="Hard Tune", command=self._on_tuner_start, state="disabled")
        self.btn_hard.pack(side="left", padx=6)

        self.log = scrolledtext.ScrolledText(self.root, height=18, wrap="word")
        self.log.pack(fill="both", expand=True, padx=10, pady=8)

        self.status_lbl = ttk.Label(self.root, text="Ready.")
        self.status_lbl.pack(fill="x", padx=10, pady=(0,8))

    def _log(self, msg: str):
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        print(msg)

    def _update_status(self, state: str):
        s = self.settings
        txt = f"{state.title()} | Rig: {s.get('rig')} | Port: {s.get('com_port')} @ {s.get('baudrate')}"
        self.status_lbl.config(text=txt)
        enable = (state == "connected")
        self.btn_toggle.config(state=("normal" if enable else "disabled"))
        self.btn_hard.config(state=("normal" if enable else "disabled"))

    def _load_rig_profile(self, name: str) -> Optional[dict]:
        fn = {"FT-710":"yaesu_ft710.json", "IC-7100":"icom_ic7100.json", "Auto":"auto.json"}.get(name, "yaesu_ft710.json")
        path = os.path.join(os.path.dirname(__file__), "rigs", fn)
        try:
            return json.loads(open(path, "r", encoding="utf-8").read())
        except Exception as e:
            self._log(f"Failed to load rig profile '{name}': {e}")
            return None

    def _init_rig(self):
        name = self.settings.get("rig", "FT-710")
        profile = self._load_rig_profile(name) or self._load_rig_profile("FT-710")
        self.rig = Rig(self.session, profile)
        self._log(f"Loaded rig profile: {profile.get('rig')} (protocol: {self.rig.protocol})")

    def _open_setup(self):
        from setup_dialog import SetupDialog
        dlg = SetupDialog(self.root, self.settings)
        self.root.wait_window(dlg)
        if getattr(dlg, "result", None):
            self.settings.update(dlg.result)
            save_settings(self.settings)
            self._log(f"Settings saved: {self.settings}")
            if self.session and self.session.is_open:
                self._init_rig()
            self._update_status("connected" if (self.session and self.session.is_open) else "disconnected")


def on_connect_toggle(self):
    # Single button toggles connect/disconnect
    if self.session and getattr(self.session, "is_open", False):
        try:
            self.session.close()
            self._log("Disconnected.")
        except Exception as e:
            try:
                messagebox.showerror("Disconnect error", str(e))
            except Exception:
                self._log(f"Disconnect error: {e}")
        finally:
            try:
                self._stop_swr_poll()
            except Exception:
                pass
            self.connect_btn.config(text="Connect")
            self._update_status("disconnected")
        return

    # Connect branch
    port = self.settings.get("com_port", "")
    baud = int(self.settings.get("baudrate", 9600))
    if not port:
        messagebox.showerror("Missing COM port", "Please configure COM Port in Setup.")
        return
    try:
        self.session = CIVSession(logger=self._log)
        try:
            self.session.owner = self
        except Exception:
            pass
        self.session.open(port, baud)
        self._init_rig()
        self._log(f"Connected to {port} @ {baud}")
        try:
            self._wire_swr_callback()
            self._start_swr_poll()
        except Exception:
            pass
        self.connect_btn.config(text="Disconnect")
        self._update_status("connected")
    except Exception as e:
        messagebox.showerror("Connection error", str(e))
        self._update_status("disconnected")
    def _on_tuner_toggle(self):
        if not self.rig:
            messagebox.showwarning("No rig", "Connect to a rig first.")
            return
        try:
            if self.tuner_enabled is True:
                self.rig.toggle_tuner(False)
                self.tuner_enabled = False
                self._log("Sent tuner OFF")
            else:
                self.rig.toggle_tuner(True)
                self.tuner_enabled = True
                self._log("Sent tuner ON")
            self.btn_toggle.config(text=("Tune Off" if self.tuner_enabled else "Tune On"))
        except Exception as e:
            messagebox.showerror("Tuner toggle error", str(e))

    def _on_tuner_start(self):
        if not self.rig:
            messagebox.showwarning("No rig", "Connect to a rig first.")
            return
        try:
            self.status_lbl.config(text="Hard Tune in progress…")
            self.btn_toggle.config(state="disabled")
            self.btn_hard.config(state="disabled")
            self.rig.hard_tune()
            self._log("✅ Hard Tune complete (rig: %s)" % self.settings.get("rig"))
        except Exception as e:
            messagebox.showerror("Hard tune error", str(e))
        finally:
            self.btn_toggle.config(state="normal")
            self.btn_hard.config(state="normal")
            self._update_status("connected" if (self.session and self.session.is_open) else "disconnected")

    def run(self):
        self.root.mainloop()

def main():
    ReminTuneApp().run()

if __name__ == "__main__":
    main()


def _wire_swr_callback(self):
    """Attach a callback on session to push SWR to bar + log."""
    try:
        if hasattr(self, "session") and self.session is not None:
            def _cb(val):
                try:
                    if self._swr_win and self._swr_win.winfo_exists():
                        self._swr_win.update_value(val if val is not None else None)
                    if val is not None:
                        try:
                            fv = float(val)
                            self._log(f"[SWR] {fv:.2f} : 1")
                        except Exception:
                            self._log(f"[SWR] {val}")
                    else:
                        self._log("[SWR] —")
                except Exception:
                    pass
            self.session.swr_update = _cb
    except Exception:
        pass

def _start_swr_poll(self):
    """Start periodic SWR polling using settings.swr_poll_interval (default 10s)."""
    try:
        interval = 10
        try:
            interval = int(self.settings.get("swr_poll_interval", 10))
            if interval <= 0: interval = 10
        except Exception:
            interval = 10
        self._swr_poll_ms = interval * 1000
        self._log(f"[SWR] Polling every {interval}s")
        if self._swr_job is not None:
            self.root.after_cancel(self._swr_job)
        self._swr_tick()
    except Exception as e:
        self._log(f"[SWR] poll start error: {e}")

def _stop_swr_poll(self):
    try:
        if self._swr_job is not None:
            self.root.after_cancel(self._swr_job)
            self._swr_job = None
    except Exception:
        pass
    # reset bar to idle
    try:
        if self._swr_win and self._swr_win.winfo_exists():
            self._swr_win.update_value(None)
    except Exception:
        pass

def _swr_tick(self):
    try:
        swr_val = None
        try:
            if hasattr(self, "rig") and self.rig is not None:
                q = getattr(self.rig, "query_swr", None)
                if callable(q):
                    swr_val = q()
        except Exception:
            swr_val = None
        if swr_val is not None:
            try:
                cb = getattr(self.session, "swr_update", None)
                if cb: cb(swr_val)
            except Exception:
                pass
        self._swr_job = self.root.after(self._swr_poll_ms, self._swr_tick)
    except Exception:
        try:
            self._swr_job = self.root.after(10000, self._swr_tick)
        except Exception:
            pass