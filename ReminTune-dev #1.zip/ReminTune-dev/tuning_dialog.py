
import tkinter as tk
from tkinter import ttk, messagebox
import time

class TuningDialog(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Hard Tune")
        self.resizable(False, False)
        self.grab_set()
        self.master = master
        self.rig = getattr(master, "rig", None)

        self.state = tk.StringVar(value="Idle")
        ttk.Label(self, textvariable=self.state, font=("Segoe UI", 10, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(10,4))

        row = ttk.Frame(self); row.grid(row=1, column=0, columnspan=3, sticky="ew", padx=10, pady=6)
        ttk.Label(row, text="SWR:").pack(side="left")
        self.swr_val = tk.StringVar(value="-")
        ttk.Label(row, textvariable=self.swr_val, width=6).pack(side="left", padx=(6,12))
        self.swr_bar = ttk.Progressbar(row, orient="horizontal", length=200, mode="determinate", maximum=200)
        self.swr_bar.pack(side="left", padx=4)

        self.start_btn = ttk.Button(self, text="Start", command=self._on_start)
        self.start_btn.grid(row=2, column=0, padx=10, pady=(6,10), sticky="e")
        self.abort_btn = ttk.Button(self, text="Abort", command=self._on_abort, state="disabled")
        self.abort_btn.grid(row=2, column=1, padx=6, pady=(6,10), sticky="w")
        self.close_btn = ttk.Button(self, text="Close", command=self.destroy)
        self.close_btn.grid(row=2, column=2, padx=10, pady=(6,10), sticky="w")

        self._running = False
        self._start_ts = None

    def _log(self, msg):
        try:
            if hasattr(self.master, "_log"):
                self.master._log(msg)
        except Exception:
            pass

    def _read_swr_update_ui(self):
        if not self.rig:
            return
        swr = self.rig.get_swr()
        if swr is not None:
            self.swr_val.set(f"{swr:.2f}")
            v = max(0, min(200, int((swr - 1.0) * 100)))
            self.swr_bar['value'] = v
        else:
            self.swr_val.set("-")
            self.swr_bar['value'] = 0

    def _on_start(self):
        if not self.rig:
            messagebox.showwarning("Not connected", "Connect to the rig first.")
            return
        if self._running:
            return
        self._running = True
        self.state.set("Tuning...")
        self.start_btn.config(state="disabled")
        self.abort_btn.config(state="normal")
        self.close_btn.config(state="disabled")
        self._start_ts = time.time()
        self._log("[Hard Tune/Dialog] start")
        self._prepare_and_start()

    def _prepare_and_start(self):
        try:
            orig_mode = self.rig.get_mode()
        except Exception:
            orig_mode = None
        try:
            orig_power = self.rig.get_power()
        except Exception:
            orig_power = None
        self._ctx = {"orig_mode": orig_mode, "orig_power": orig_power, "changed_mode": False, "changed_power": False}

        can_restore_mode = bool(orig_mode)
        if can_restore_mode and (orig_mode != "03"):
            try:
                self.rig.set_mode("03")
                self._ctx["changed_mode"] = True
                time.sleep(0.1)
            except Exception as e:
                self._log(f"[Hard Tune/Dialog] set CW failed: {e}")

        try:
            pct = int(getattr(self.master, "settings", {}).get("tune_power_pct") or 20)
        except Exception:
            pct = 20
        try:
            self.rig.set_power_pct(pct)
            self._ctx["changed_power"] = True
            time.sleep(0.1)
        except Exception as e:
            self._log(f"[Hard Tune/Dialog] set power failed: {e}")

        try:
            self.rig.tx_on(); time.sleep(0.2)
        except Exception:
            pass
        try:
            self.rig.start_hard_tune()
        except Exception as e:
            self._log(f"[Hard Tune/Dialog] start hard_tune failed: {e}")

        self._poll_loop()

    def _poll_loop(self):
        if not self._running:
            return
        self._read_swr_update_ui()
        try:
            self.rig.poll_tuner_status_once()
        except Exception:
            pass

        try:
            duration = int(getattr(self.master, "settings", {}).get("hard_tune_sec") or 4)
        except Exception:
            duration = 4

        if time.time() - self._start_ts >= duration:
            self._finish()
            return
        self.after(200, self._poll_loop)

    def _finish(self):
        try: self.rig.tx_off()
        except Exception: pass
        try:
            if self._ctx.get("changed_mode") and self._ctx.get("orig_mode"):
                self.rig.set_mode(self._ctx["orig_mode"])
            if self._ctx.get("changed_power") and (self._ctx.get("orig_power") is not None):
                self.rig.set_power_pct(int(self._ctx["orig_power"]))
        except Exception as e:
            self._log(f"[Hard Tune/Dialog] restore failed: {e}")

        self._read_swr_update_ui()
        self.state.set("Done")
        self._running = False
        self.start_btn.config(state="normal")
        self.abort_btn.config(state="disabled")
        self.close_btn.config(state="normal")
        self._log("[Hard Tune/Dialog] done")

    def _on_abort(self):
        if not self._running:
            return
        self._running = False
        try: self.rig.tx_off()
        except Exception: pass
        try: self.rig.tune_off()
        except Exception: pass
        self.state.set("Aborted")
        self.start_btn.config(state="normal")
        self.abort_btn.config(state="disabled")
        self.close_btn.config(state="normal")
        self._log("[Hard Tune/Dialog] aborted")
