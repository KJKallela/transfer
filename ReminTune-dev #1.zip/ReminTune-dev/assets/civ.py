# CIV handling module
