## v1.2.26 RC4
- Added FT-710 + IC-7100 hard tune
- Settings saving fixed
- Logo assets included
