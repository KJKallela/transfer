# Rigs definitions (FT-710, IC-7100)
