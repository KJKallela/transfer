
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk, messagebox
import time, json, sys
try:
    import serial
except Exception:
    serial = None
from pathlib import Path

from settings import load_settings, save_settings
from setup_dialog import SetupDialog
from civ import CIVSession
from rigs.rigs import Rig
from tuning_dialog import TuningDialog
from version import __version__

def resource_path(*parts):
    base = getattr(sys, '_MEIPASS', Path(__file__).resolve().parent)
    return Path(base, *parts)

def load_profile(rig_name: str) -> dict:
    p = resource_path('rigs', 'yaesu_ft710.json') if rig_name == 'FT-710' else resource_path('rigs', 'icom_ic7100.json')
    with open(p, 'r', encoding='utf-8') as f:
        return json.load(f)

class SevenSegCanvas(tk.Canvas):
    SEG_MAP = {
        '0': ('a','b','c','d','e','f'),
        '1': ('b','c'),
        '2': ('a','b','g','e','d'),
        '3': ('a','b','g','c','d'),
        '4': ('f','g','b','c'),
        '5': ('a','f','g','c','d'),
        '6': ('a','f','e','d','c','g'),
        '7': ('a','b','c'),
        '8': ('a','b','c','d','e','f','g'),
        '9': ('a','b','c','d','f','g'),
        '-': ('g',),
        ' ': tuple()
    }
    def __init__(self, master, digits=9, seg_w=12, seg_h=40, gap=6, theme="amber", **kw):
        super().__init__(master, height=seg_h+24, highlightthickness=0, **kw)
        self.title('ReminTune')
        print('DEBUG: finished __init__ of ReminTuneApp, title set')
        self._build_ui()
        self.title('ReminTune')
        print('DEBUG: finished __init__ of ReminTuneApp, title set')
        self._build_ui()
        self.digits = digits
        self.seg_w = seg_w
        self.seg_h = seg_h
        self.gap = gap
        self.theme = theme
        self.items = []
        self._build(theme)

    def _color(self, theme):
        # Post-UI initialization for title and license info
        callsign = getattr(self.settings, 'my_hamcall', None)
        if not callsign:
            callsign = 'Unregistered copy'
        self.license_var.set(f'Licensed to: {callsign}')
        self._update_license_color(callsign)
        self.title(f"ReminTune {__version__} (RC5p17, 2025-09-25) – Licensed to: {callsign}")
        if theme == "green":
            return ("#0a2", "#021", "#093")  # lit, bg, dim
        return ("#F8D37E", "#4A3E12", "#C8A85E")  # lit, bg, dim

    def set_theme(self, theme):
        self.theme = theme
        self._build(theme)

    def _build(self, theme):
        self.delete("all")
        lit, bg, dim = self._color(theme)
        self.configure(bg=bg)
        self.items = []
        x = 8
        for i in range(self.digits):
            self.items.append(self._draw_digit(x, 8, lit, dim))
            x += self.seg_w + self.seg_h + self.gap
        # decimal points
        self.dp_items = []
        x = 8 + self.seg_w + self.seg_h - 4
        for i in range(self.digits):
            dp = self.create_oval(x, 8 + self.seg_h + 4, x+6, 8 + self.seg_h + 10, fill=dim, outline="")
            self.dp_items.append(dp)
            x += self.seg_w + self.seg_h + self.gap

    def _draw_digit(self, x, y, lit, dim):
        sh = self.seg_h
        a = self.create_rectangle(x, y, x+sh, y+4, fill=dim, outline="")
        d = self.create_rectangle(x, y+sh+8, x+sh, y+sh+12, fill=dim, outline="")
        g = self.create_rectangle(x, y+(sh//2)+4, x+sh, y+(sh//2)+8, fill=dim, outline="")
        f = self.create_rectangle(x, y, x+4, y+(sh//2)+4, fill=dim, outline="")
        b = self.create_rectangle(x+sh-4, y, x+sh, y+(sh//2)+4, fill=dim, outline="")
        e = self.create_rectangle(x, y+(sh//2)+8, x+4, y+sh+8, fill=dim, outline="")
        c = self.create_rectangle(x+sh-4, y+(sh//2)+8, x+sh, y+sh+8, fill=dim, outline="")
        return {'a':a,'b':b,'c':c,'d':d,'e':e,'f':f,'g':g,'lit':lit,'dim':dim}

    def _set_digit(self, idx, ch):
        if idx < 0 or idx >= len(self.items): return
        segs = self.items[idx]
        lit, dim = segs['lit'], segs['dim']
        for key in ('a','b','c','d','e','f','g'):
            self.itemconfig(segs[key], fill=dim)
        on = self.SEG_MAP.get(ch, ())
        for k in on:
            self.itemconfig(segs[k], fill=lit)

    def _set_dp(self, idx, on):
        if idx < 0 or idx >= len(self.dp_items): return
        segs = self.items[idx]
        lit, dim = segs['lit'], segs['dim']
        self.itemconfig(self.dp_items[idx], fill=lit if on else dim)

    def draw_text(self, s: str):
        clean = []
        for ch in s:
            if ch.isdigit() or ch in '.- ':
                clean.append(ch)
        s2 = ''.join(clean)
        chars = []
        dps = []
        for ch in s2:
            if ch == '.':
                if chars:
                    dps[-1] = True
                continue
            chars.append(ch)
            dps.append(False)
        if len(chars) < self.digits:
            chars = ([' ']*(self.digits - len(chars))) + chars
            dps   = ([False]*(self.digits - len(dps))) + dps
        else:
            chars = chars[-self.digits:]
            dps   = dps[-self.digits:]
        for i, ch in enumerate(chars):
            self._set_digit(i, ch)
            self._set_dp(i, dps[i])

class ReminTuneApp(tk.Tk):
    def _update_license_color(self, callsign: str):
        if callsign == 'Unregistered copy':
            self.license_label.config(fg='blue')
        else:
            self.license_label.config(fg='black')

    def _update_status_color(self, connected: bool):
        if connected:
            self.status_label.config(fg='green')
        else:
            self.status_label.config(fg='red')

    def _show_about(self):
        about_win = tk.Toplevel(self)
        about_win.title('About ReminTune')
        about_win.geometry('400x260')
        if hasattr(self, 'icon_image'):
            icon_label = tk.Label(about_win, image=self.icon_image)
            icon_label.pack(pady=10)
        ver_label = tk.Label(about_win, text=f'ReminTune {__version__} (RC5p17, 2025-09-25)')
        ver_label.pack(pady=5)
        copy_label = tk.Label(about_win, text='© 2025 Kimmo Kallela – All rights reserved')
        copy_label.pack(pady=5)

    def _update_indicators(self):
        """Placeholder update method (auto-stub)."""
        pass

    def _refresh_all_now(self):
        """Placeholder refresh method (auto-stub)."""
        pass

    def _update_tune_toggle_state(self, disabled: bool = False):
        """Enable or disable the TUNE button if present."""
        state = 'disabled' if disabled else 'normal'
        if hasattr(self, 'tune_button'):
            try:
                self.tune_button.configure(state=state)
            except Exception:
                pass

    def __init__(self):
        super().__init__()
        self.title('ReminTune')
        print('DEBUG: finished __init__ of ReminTuneApp, title set')
        self._build_ui()
        self.title('ReminTune')
        print('DEBUG: finished __init__ of ReminTuneApp, title set')
        self._build_ui()

    def _open_log_file(self):
        try:
            import os
            appdata = os.environ.get('APPDATA')
            base = Path(appdata) / 'ReminTune' / 'logs' if appdata else Path.cwd() / 'logs'
            base.mkdir(parents=True, exist_ok=True)
            ts = time.strftime('%Y%m%d_%H%M%S')
            self._log_path = base / f'log_{ts}.txt'
            self._log_fp = open(self._log_path, 'a', encoding='utf-8')
            self._log(f"[AutoLog] Writing to {self._log_path}")
        except Exception as e:
            self._log(f"[AutoLog ERROR] {e}")

def _refresh_all_now(self):
    if not self.rig:
        return
    # frequency
    try:
        hz = self.rig.get_frequency()
        if hz:
            val = self._format_freq(hz)
            self.last_freq_str = val
            if getattr(self, 'use_7seg', False) and getattr(self, 'freq_canvas', None):
                self.freq_canvas.draw_text(val)
            else:
                self.freq_var.set(val)
    except Exception:
        pass
    # mode
    try:
        md = self.rig.get_mode()
        if md:
            self.mode_var.set(self._mode_name(md))
    except Exception:
        pass
    # tuner
    try:
        is_on, raw = self.rig.query_tuner_status()
        if is_on is not None:
            self.tuner_is_on = is_on
            self.tuner_var.set("ON" if is_on else "OFF")
    except Exception:
        pass
    # tx explicit (if supported), else heuristic
    try:
        tx = None
        if hasattr(self.rig, 'query_tx_status'):
            tx = self.rig.query_tx_status()
        if tx is None and hasattr(self.rig, 'is_transmitting_hint'):
            tx = self.rig.is_transmitting_hint()
        if tx is not None:
            self.tx_is_on = bool(tx)
    except Exception:
        pass
    self._update_tune_toggle_state(disabled=False)
    self._update_indicators()


    def _update_tune_toggle_state(self, disabled: bool = False):
        if disabled:
            label = "Tune Mode: (disabled)"; style = 'Tune.Disabled.TButton'
        else:
            if self.tuner_is_on:
                label = "Tune Mode: ON"; style = 'Tune.On.TButton'
            else:
                label = "Tune Mode: OFF"; style = 'Tune.Off.TButton'
        self.tune_toggle_btn.config(state=("disabled" if disabled else "normal"), text=label, style=style)
        led_color = '#2e7d32' if (not disabled and self.tuner_is_on) else ('#9e9e9e' if not disabled else '#cccccc')
        try:
            self.tune_led.itemconfig(self._led_id, fill=led_color)
        except Exception:
            pass

    def query_tuner_status(self):
        if not self.rig: return
        is_on, raw = self.rig.query_tuner_status()
        self.tuner_is_on = is_on
        self.tuner_var.set("ON" if is_on else "OFF" if is_on is not None else "-")
        self._log(f"[Tuner status] is_on={is_on} raw={raw}")
        self._update_tune_toggle_state(disabled=False)
        self._update_indicators()


def hard_tune(self):
    if not self.rig:
        from tkinter import messagebox
        messagebox.showwarning("Not connected", "Connect to the rig first.")
        return
    dlg = TuningDialog(self)
    self.wait_window(dlg)
    try:
        self.query_tuner_status()
    except Exception:
        pass


def toggle_tuner_off_on(self):
    if not self.rig:
        from tkinter import messagebox
        messagebox.showwarning("Not connected", "Connect to the rig first.")
        return
    enable = not bool(self.tuner_is_on)
    try:
        self.rig.toggle_tuner(enable)
        import time as _t; _t.sleep(0.2)
        self.query_tuner_status()
        self._log(f"[Tuner toggle] -> {'ON' if enable else 'OFF'}")
    except Exception as e:
        self._log(f"[Tuner toggle ERROR] {e}")
        from tkinter import messagebox
        messagebox.showerror("Toggle failed", str(e))
    self._update_indicators()

    def toggle_tuner_off_on(self):
        if not self.rig:
            messagebox.showwarning("Not connected", "Connect to the rig first.")
            return
        enable = not bool(self.tuner_is_on)
        try:
            self.rig.toggle_tuner(enable)
            time.sleep(0.2)
            self.query_tuner_status()
            self._log(f"[Tuner toggle] -> {'ON' if enable else 'OFF'}")
        except Exception as e:
            self._log(f"[Tuner toggle ERROR] {e}")
            messagebox.showerror("Toggle failed", str(e))
        self._update_indicators()


def hard_tune(self):
    if not self.rig:
        from tkinter import messagebox
        messagebox.showwarning("Not connected", "Connect to the rig first.")
        return
    dlg = TuningDialog(self)
    self.wait_window(dlg)
    try:
        self.query_tuner_status()
    except Exception:
        pass

    def hard_tune(self):
        if not self.rig:
            messagebox.showwarning("Not connected", "Connect to the rig first.")
            return
        dlg = TuningDialog(self)
        self.wait_window(dlg)
        try:
            self.query_tuner_status()
        except Exception:
            pass

    def _format_freq(self, hz):
        try:
            hz = int(hz)
            mhz = hz / 1_000_000.0
            s = f"{mhz:0.6f}"
            return s
        except Exception:
            return "— — — — — — . — — —"

    def _mode_name(self, md_hex: str) -> str:
        table = {"01":"LSB","02":"USB","03":"CW","05":"AM","06":"FM","08":"DIGI-L","09":"DIGI-U","10":"RTTY-L","11":"RTTY-U"}
        return table.get((md_hex or "").upper(), md_hex or "-")

    def _start_polling(self):
        try:
            if getattr(self, "_poll_job", None):
                self.after_cancel(self._poll_job)
        except Exception:
            pass
        self._poll_job = self.after(500, self._poll_tick)

    def _stop_polling(self):
        try:
            if getattr(self, "_poll_job", None):
                self.after_cancel(self._poll_job)
        except Exception:
            pass
        self._poll_job = None

    def _poll_tick(self):
        try:
            if self.rig:
                hz = self.rig.get_frequency()
                if hz:
                    val = self._format_freq(hz)
                    self.last_freq_str = val
                    if getattr(self, 'use_7seg', False) and getattr(self, 'freq_canvas', None):
                        self.freq_canvas.draw_text(val)
                    else:
                        self.freq_var.set(val)
        except Exception:
            pass
        try:
            if self.rig:
                md = self.rig.get_mode()
                if md:
                    self.mode_var.set(self._mode_name(md))
        except Exception:
            pass
        try:
            if self.rig:
                self._tuner_poll_div = (self._tuner_poll_div + 1) % 3
                if self._tuner_poll_div == 0:
                    is_on, raw = self.rig.query_tuner_status()
                    if is_on is not None:
                        self.tuner_is_on = is_on
                        self.tuner_var.set("ON" if is_on else "OFF")
                        self._update_tune_toggle_state(disabled=False)
        except Exception:
            pass
        try:
            self._tx_poll_div = (self._tx_poll_div + 1) % 2
            if self._tx_poll_div == 0 and self.rig:
                tx = self.rig.is_transmitting_hint()
                if tx is not None:
                    self.tx_is_on = bool(tx)
        except Exception:
            pass
        self._update_indicators()
        self._poll_job = self.after(700, self._poll_tick)

    # --- Context menus & exports ---
    def _copy_from_widget(self, widget):
        try:
            sel = widget.selection_get()
        except Exception:
            sel = widget.get("1.0", "end-1c") if hasattr(widget, "get") else ""
        if sel:
            self.clipboard_clear()
            self.clipboard_append(sel)
            try: self.status.set("Copied to clipboard")
            except Exception: pass

    def _save_text_to_file(self, content: str, default_name: str):
        if not content:
            return
        try:
            from tkinter import filedialog
            import time as _t
            ts = _t.strftime("%Y%m%d_%H%M%S")
            fname = f"{default_name}_{ts}.txt"
            path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile=fname,
                                                filetypes=[("Text files","*.txt"),("All files","*.*")])
            if path:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                try:
                    self.status.set(f"Saved: {path}")
                except Exception:
                    pass
        except Exception as e:
            try: self._log(f"[Save ERROR] {e}")
            except Exception: pass

    def _save_selection(self, widget):
        try:
            sel = widget.selection_get()
        except Exception:
            sel = ""
        if sel:
            self._save_text_to_file(sel, "ReminTune_selection")
        else:
            try: self.status.set("No selection to save")
            except Exception: pass

    def _save_full_log(self):
        try:
            content = self.logbox.get("1.0", "end-1c")
        except Exception:
            content = ""
        self._save_text_to_file(content, "ReminTune_log")

    def _show_log_context(self, event):
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Copy selection", command=lambda: self._copy_from_widget(self.logbox))
        menu.add_command(label="Select all", command=lambda: self.logbox.tag_add("sel", "1.0", "end-1c"))
        menu.add_separator()
        menu.add_command(label="Save selection as...", command=lambda: self._save_selection(self.logbox))
        menu.add_command(label="Save full log as...", command=self._save_full_log)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _show_lcd_context(self, event):
        snapshot = f"""Frequency: {self.last_freq_str}
Mode: {self.mode_var.get()}
Tuner: {self.tuner_var.get()}"""
        menu = tk.Menu(self, tearoff=0)
        def _copy_snapshot():
            self.clipboard_clear()
            self.clipboard_append(snapshot)
            try:
                self.status.set("Display snapshot copied")
            except Exception:
                pass
        menu.add_command(label="Copy display snapshot", command=_copy_snapshot)
        menu.add_command(label="Save display snapshot as...", command=lambda: self._save_text_to_file(snapshot, "ReminTune_display_snapshot"))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
def _update_tune_toggle_state(self, disabled: bool = False):
    if disabled:
        label = "Tune Mode: (disabled)"; style = 'Tune.Disabled.TButton'
    else:
        if self.tuner_is_on:
            label = "Tune Mode: ON"; style = 'Tune.On.TButton'
        else:
            label = "Tune Mode: OFF"; style = 'Tune.Off.TButton'
    self.tune_toggle_btn.config(state=("disabled" if disabled else "normal"), text=label, style=style)
    led_color = '#2e7d32' if (not disabled and self.tuner_is_on) else ('#9e9e9e' if not disabled else '#cccccc')
    try:
        self.tune_led.itemconfig(self._led_id, fill=led_color)
    except Exception:
        pass

def _show_log_context(self, event):
    menu = tk.Menu(self, tearoff=0)
    menu.add_command(label="Copy selection", command=lambda: self._copy_from_widget(self.logbox))
    menu.add_command(label="Select all", command=lambda: self.logbox.tag_add("sel", "1.0", "end-1c"))
    menu.add_separator()
    menu.add_command(label="Save selection as...", command=lambda: self._save_selection(self.logbox))
    menu.add_command(label="Save full log as...", command=self._save_full_log)
    try:
        menu.tk_popup(event.x_root, event.y_root)
    finally:
        menu.grab_release()


    def _show_lcd_context(self, event):
        snapshot = f"""Frequency: {getattr(self, 'last_freq_str', self.freq_var.get() if hasattr(self, 'freq_var') else '')}
Mode: {self.mode_var.get() if hasattr(self, 'mode_var') else ''}
Tuner: {self.tuner_var.get() if hasattr(self, 'tuner_var') else ''}"""
        menu = tk.Menu(self, tearoff=0)
        def _copy_snapshot():
            try:
                self.clipboard_clear()
                self.clipboard_append(snapshot)
                self.status.set("Display snapshot copied")
            except Exception:
                pass
        menu.add_command(label="Copy display snapshot", command=_copy_snapshot)
        menu.add_command(label="Save display snapshot as...", command=lambda: self._save_text_to_file(snapshot, "ReminTune_display_snapshot"))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()


def _launch_app():
    app = ReminTuneApp(); app.mainloop()

if __name__ == "__main__":
    _launch_app()

    def _build_ui(self):
        print('DEBUG: entering _build_ui')
        try:
            # Intentional test widget
            test_label = ttk.Label(self, text="DEBUG TEST LABEL", foreground="red")
            test_label.pack(pady=20)

            print('DEBUG: finishing _build_ui')
            self.update_idletasks()
            self.update()
        except Exception as e:
            print('ERROR in _build_ui:', e)
