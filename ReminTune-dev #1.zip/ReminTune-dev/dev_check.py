
import ast, pathlib, sys
root = pathlib.Path(__file__).resolve().parent
txt = (root/"main.py").read_text(encoding="utf-8")
t = ast.parse(txt)
cls = next((n for n in t.body if isinstance(n, ast.ClassDef) and n.name=="ReminTuneApp"), None)
errs = []
if not cls:
    errs.append("ReminTuneApp missing")
else:
    methods = {n.name for n in cls.body if isinstance(n, ast.FunctionDef)}
    for need in ("_show_lcd_context","_show_log_context","toggle_tuner_off_on","hard_tune","_build_ui","_start_polling","_poll_tick"):
        if need not in methods:
            errs.append(f"Missing method: {need}")
    if '.bind("<Button-3>", lambda e: self._show_lcd_context(e))' not in txt:
        errs.append("LCD bind is not using lambda")
    if 'self.logbox.bind("<Button-3>", lambda e: self._show_log_context(e))' not in txt:
        errs.append("Log bind is not using lambda")
if errs:
    print("\n".join(errs)); sys.exit(1)
print("OK: context-menu methods & binds present.")
