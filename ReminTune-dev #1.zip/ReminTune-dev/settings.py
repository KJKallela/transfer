
from __future__ import annotations
import json, os
from pathlib import Path
from typing import Any, Dict


DEFAULTS: Dict[str, Any] = {
    "com_port": "COM3",
    "baudrate": 9600,
    "rig": "FT-710",
    "auto_detect_rig": False,
    "tune_power_w": 20,
    "preferred_mode": "MD03",
    "tune_power_pct": 20,
    "tune_mode": "CW",
    "hard_tune_sec": 4,
    "use_7seg_lcd": True,
    "lcd_theme": "amber",  # amber|green
    "auto_log": False
}

def _appdata_dir() -> Path:
    appdata = os.environ.get("APPDATA")
    if appdata:
        d = Path(appdata) / "ReminTune"
        d.mkdir(parents=True, exist_ok=True)
        return d
    return Path(__file__).resolve().parent

def settings_path() -> Path:
    return _appdata_dir() / "settings.json"

def load_settings(path: Path | None = None) -> Dict[str, Any]:
    path = path or settings_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except Exception:
        data = {}
    out = DEFAULTS.copy()
    if isinstance(data, dict):
        out.update(data)
    return out

def save_settings(s: Dict[str, Any], path: Path | None = None) -> bool:
    path = path or settings_path()
    try:
        cur = load_settings()
        cur.update(s or {})
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(cur, indent=2), encoding="utf-8")
        tmp.replace(path)
        return True
    except Exception:
        return False
