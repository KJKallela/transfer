Place your application icon here as 'remintune.ico' (recommended 256x256, multi-size ICO).
If present, the build script will embed it into ReminTune.exe automatically.