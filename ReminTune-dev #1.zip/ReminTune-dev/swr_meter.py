
import tkinter as tk
from tkinter import ttk

class SWRBarWindow(tk.Toplevel):
    """Floating always-on-top SWR bar (1.0..5.0)."""
    def __init__(self, master=None, title="SWR Indicator", **kwargs):
        super().__init__(master, **kwargs)
        self.title(title)
        self.resizable(False, False)
        try:
            self.attributes("-topmost", True)
        except Exception:
            pass

        self._value = None  # None => idle / disconnected
        self._min = 1.0
        self._max = 5.0

        wrap = ttk.Frame(self, padding=10)
        wrap.pack(fill="both", expand=True)

        self.label = ttk.Label(wrap, text="SWR: —", foreground="#cccccc")
        self.label.pack(anchor="w", pady=(0,6))

        self.canvas = tk.Canvas(wrap, width=360, height=26, bg="#1a1a1a", highlightthickness=0)
        self.canvas.pack()

        leg = ttk.Frame(wrap)
        leg.pack(fill="x", pady=(6,0))
        ttk.Label(leg, text="1.0").pack(side="left")
        ttk.Label(leg, text="5.0").pack(side="right")

        self._draw_bar()

    def update_value(self, swr):
        try:
            if swr is None:
                self._value = None
            else:
                v = float(swr)
                v = max(self._min, min(v, self._max))
                self._value = v
        except Exception:
            return
        self._draw_bar()

    def _draw_bar(self):
        c = self.canvas
        c.delete("all")
        w = int(c["width"]); h = int(c["height"])
        c.create_rectangle(0,0,w,h, fill="#2b2b2b", outline="")
        if self._value is None:
            self.label.configure(text="SWR: —", foreground="#bbbbbb")
            return
        frac = (self._value - self._min) / (self._max - self._min) if self._max>self._min else 0.0
        fill_w = int(w * frac)
        if self._value < 2.0:
            color = "#26c281"  # green
        elif self._value < 3.0:
            color = "#f5d76e"  # yellow
        else:
            color = "#f64747"  # red
        c.create_rectangle(0,0,fill_w,h, fill=color, outline="")
        self.label.configure(text=f"SWR: {self._value:.2f} : 1", foreground=color)
