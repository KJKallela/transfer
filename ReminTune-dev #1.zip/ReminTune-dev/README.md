
# ReminTune 1.3.0-RC5p5

Fix: display context menu (_show_lcd_context) indentation & f-string; includes RC5p1/p2/p3/p4 features.

- LCD-style frequency, mode, tuner status (live polling)
- 3‑state Connect/Test/Disconnect
- Right-click menus for log and display snapshot (copy/save)
- Wider default window (980×560)
- Test Connection import fix

## Run from source
```
py -m pip install pyserial
py main.py
```

## Quick self-check
```
py dev_check.py
```
