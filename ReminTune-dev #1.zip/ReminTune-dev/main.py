import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
import serial
import time
import json
import os

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

import rigs   # <--- uses rigs.py

APP_TITLE = "ReminTune"
APP_VERSION = "1.3.0-DEV"
CONFIG_FILE = "config.json"

DEFAULT_SETTINGS = {
    "radio_model": "Yaesu FT-710",
    "com_port": "COM3",
    "baud_rate": 19200,
    "ptt_method": "CAT",
    "default_power": 50,
    "tune_time": 3,
    "live_meters": True,
    "meter_interval": 1,
    "meters_visible": True,
    "setup_geometry": None,
    "main_geometry": None,
    "last_test_status": "Not tested"
}


class ReminTuneApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_TITLE} {APP_VERSION}")

        self.settings = self.load_settings()

        if self.settings.get("main_geometry"):
            try:
                self.root.geometry(self.settings["main_geometry"])
            except Exception:
                pass

        # Load rig profile
        self.rig_profile = rigs.load_rig_profile(self.settings.get("radio_model", "Yaesu FT-710"))

        # ----- Menu -----
        menubar = tk.Menu(self.root)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Exit", command=self.on_close)
        menubar.add_cascade(label="File", menu=file_menu)

        settings_menu = tk.Menu(menubar, tearoff=0)
        settings_menu.add_command(label="Setup...", command=self.open_setup_window)
        settings_menu.add_command(label="Hard Tune", command=self.hard_tune)
        settings_menu.add_command(label="List Rig Profiles", command=self.list_rig_profiles)
        menubar.add_cascade(label="Settings", menu=settings_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="About", command=self.show_about)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.root.config(menu=menubar)

        # ----- Layout -----
        main_frame = tk.Frame(root)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Log area
        self.log_area = scrolledtext.ScrolledText(main_frame, width=70, height=20, state="disabled")
        self.log_area.pack(side=tk.LEFT, padx=5, pady=5, fill=tk.BOTH, expand=True)

        # Control panel
        ctrl = tk.Frame(main_frame)
        ctrl.pack(side=tk.RIGHT, padx=10, pady=5, anchor="ne")

        tk.Button(ctrl, text="Read Frequency (F5)", command=self.read_frequency, width=20).pack(pady=3)
        tk.Button(ctrl, text="PTT ON (F2)", command=self.ptt_on, width=20).pack(pady=3)
        tk.Button(ctrl, text="PTT OFF (F3)", command=self.ptt_off, width=20).pack(pady=3)

        self.tune_active = False
        self.tune_button = tk.Button(ctrl, text="Start Tune (F1)", command=self.toggle_tune, width=20)
        self.tune_button.pack(pady=3)

        # Status light
        status_frame = tk.Frame(ctrl)
        status_frame.pack(pady=8)
        self.status_canvas = tk.Canvas(status_frame, width=20, height=20, highlightthickness=0)
        self.status_canvas.pack(side=tk.LEFT, padx=5)
        self.status_light = self.status_canvas.create_oval(2, 2, 18, 18, fill="grey")
        tk.Label(status_frame, text="Status").pack(side=tk.LEFT)

        # Meters toggle + frame
        self.meter_toggle_btn = tk.Button(ctrl, text="Hide Meters", command=self.toggle_meters)
        self.meter_toggle_btn.pack(pady=(10, 2))

        self.meter_frame = tk.Frame(ctrl)
        self.meter_frame.pack()

        self.swr_label = tk.Label(self.meter_frame, text="SWR: --", fg="grey", font=("TkDefaultFont", 10, "bold"))
        self.swr_label.pack(pady=3)

        self.power_label = tk.Label(self.meter_frame, text="Power: -- W", fg="grey", font=("TkDefaultFont", 10, "bold"))
        self.power_label.pack(pady=3)

        self.alc_label = tk.Label(self.meter_frame, text="ALC: --", fg="grey", font=("TkDefaultFont", 10, "bold"))
        self.alc_label.pack(pady=3)

        # SWR history chart
        self.swr_history = []
        self.swr_fig = Figure(figsize=(2.5, 1.2), dpi=100)
        self.swr_ax = self.swr_fig.add_subplot(111)
        self.swr_ax.set_title("SWR History", fontsize=8)
        self.swr_ax.set_ylim(1, 3)
        self.swr_ax.set_xlim(0, 60)
        self.swr_ax.set_ylabel("SWR", fontsize=7)
        self.swr_line, = self.swr_ax.plot([], [], color="blue")
        self.swr_canvas = FigureCanvasTkAgg(self.swr_fig, master=self.meter_frame)
        self.swr_canvas.get_tk_widget().pack(pady=5)

        # Power history chart
        self.power_history = []
        self.power_fig = Figure(figsize=(2.5, 1.2), dpi=100)
        self.power_ax = self.power_fig.add_subplot(111)
        self.power_ax.set_title("Power History", fontsize=8)
        self.power_ax.set_ylim(0, 100)
        self.power_ax.set_xlim(0, 60)
        self.power_ax.set_ylabel("W", fontsize=7)
        self.power_line, = self.power_ax.plot([], [], color="red")
        self.power_canvas = FigureCanvasTkAgg(self.power_fig, master=self.meter_frame)
        self.power_canvas.get_tk_widget().pack(pady=5)

        if not self.settings.get("meters_visible", True):
            self.meter_frame.pack_forget()
            self.meter_toggle_btn.config(text="Show Meters")

        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        self.status_bar = tk.Label(root, textvariable=self.status_var, bd=1, relief=tk.SUNKEN, anchor="w")
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # Shortcuts
        root.bind("<F1>", lambda e: self.toggle_tune())
        root.bind("<F2>", lambda e: self.ptt_on())
        root.bind("<F3>", lambda e: self.ptt_off())
        root.bind("<F5>", lambda e: self.read_frequency())

        self.ser = None
        self.connect_serial()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.update_meters()

    # ----------------- New method -----------------
    def list_rig_profiles(self):
        """List all available rig profiles and their friendly names."""
        rigs_dir = os.path.join(os.path.dirname(__file__), "rigs")
        if not os.path.exists(rigs_dir):
            self.log("❌ rigs/ directory not found!")
            return

        files = [f for f in os.listdir(rigs_dir) if f.endswith(".json")]
        if not files:
            self.log("❌ No JSON rig profiles found in rigs/")
            return

        self.log("🔍 Rig profiles found:")
        for f in files:
            path = os.path.join(rigs_dir, f)
            try:
                with open(path, "r", encoding="utf-8") as jf:
                    data = json.load(jf)
                    display = data.get("name", os.path.splitext(f)[0])
                    self.log(f"   ✅ {f} -> {display}")
            except Exception as e:
                self.log(f"   ⚠️ Could not parse {f}: {e}")

        current = self.settings.get("radio_model", "Unknown")
        profile = rigs.load_rig_profile(current)
        if profile:
            self.log(f"✅ Current profile loaded OK: {current}")
        else:
            self.log(f"❌ Could not load current profile: {current}")

    # ----------------- Setup Window -----------------
    def open_setup_window(self):
        win = tk.Toplevel(self.root)
        win.title("Setup")
        win.grab_set()

        if self.settings.get("setup_geometry"):
            try:
                win.geometry(self.settings["setup_geometry"])
            except Exception:
                pass

        rigs_dir = os.path.join(os.path.dirname(__file__), "rigs")
        rig_files = [f for f in os.listdir(rigs_dir) if f.endswith(".json")]

        rig_names = []
        rig_map = {}
        for f in rig_files:
            path = os.path.join(rigs_dir, f)
            try:
                with open(path, "r", encoding="utf-8") as jf:
                    data = json.load(jf)
                    display = data.get("name") or os.path.splitext(f)[0].replace("_", " ").title()
                    rig_names.append(display)
                    rig_map[display] = data.get("name", display)
            except Exception:
                display = os.path.splitext(f)[0].replace("_", " ").title()
                rig_names.append(display)
                rig_map[display] = display

        tk.Label(win, text="Radio Model:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
        model_var = tk.StringVar(value=self.settings["radio_model"])
        model_combo = ttk.Combobox(win, textvariable=model_var,
                                   values=rig_names, state="readonly")
        model_combo.grid(row=0, column=1, padx=5, pady=5)

        # COM Port
        tk.Label(win, text="COM Port:").grid(row=1, column=0, padx=5, pady=5, sticky="e")
        com_entry = tk.Entry(win)
        com_entry.insert(0, self.settings["com_port"])
        com_entry.grid(row=1, column=1, padx=5, pady=5)

        # Baud Rate
        tk.Label(win, text="Baud Rate:").grid(row=2, column=0, padx=5, pady=5, sticky="e")
        baud_entry = tk.Entry(win)
        baud_entry.insert(0, str(self.settings["baud_rate"]))
        baud_entry.grid(row=2, column=1, padx=5, pady=5)

        # PTT Method
        tk.Label(win, text="PTT Method:").grid(row=3, column=0, padx=5, pady=5, sticky="e")
        ptt_var = tk.StringVar(value=self.settings["ptt_method"])
        ptt_combo = ttk.Combobox(win, textvariable=ptt_var,
                                 values=["CAT", "RTS", "DTR"], state="readonly")
        ptt_combo.grid(row=3, column=1, padx=5, pady=5)

        # Default Power
        tk.Label(win, text="Default Power (%):").grid(row=4, column=0, padx=5, pady=5, sticky="e")
        power_entry = tk.Entry(win)
        power_entry.insert(0, str(self.settings["default_power"]))
        power_entry.grid(row=4, column=1, padx=5, pady=5)

        # Tune Time
        tk.Label(win, text="Tune Time (s):").grid(row=5, column=0, padx=5, pady=5, sticky="e")
        tune_entry = tk.Entry(win)
        tune_entry.insert(0, str(self.settings.get("tune_time", 3)))
        tune_entry.grid(row=5, column=1, padx=5, pady=5)

        # Live meters
        live_var = tk.BooleanVar(value=self.settings.get("live_meters", True))
        tk.Checkbutton(win, text="Enable live meters", variable=live_var).grid(row=6, column=0, columnspan=2, pady=5)

        # Meter interval
        tk.Label(win, text="Meter Update Interval (s):").grid(row=7, column=0, padx=5, pady=5, sticky="e")
        interval_entry = tk.Entry(win)
        interval_entry.insert(0, str(self.settings.get("meter_interval", 1)))
        interval_entry.grid(row=7, column=1, padx=5, pady=5)

        btns = tk.Frame(win)
        btns.grid(row=8, column=0, columnspan=2, pady=10)

        status_label = tk.Label(win, text=self.settings.get("last_test_status", "Not tested"), fg="grey")
        status_label.grid(row=9, column=0, columnspan=2, pady=(0, 10))

        def save_and_close():
            selected_name = model_var.get()
            self.settings["radio_model"] = selected_name
            self.settings["com_port"] = com_entry.get()
            self.settings["baud_rate"] = int(baud_entry.get())
            self.settings["ptt_method"] = ptt_var.get()
            self.settings["default_power"] = int(power_entry.get())
            self.settings["tune_time"] = int(tune_entry.get())
            self.settings["live_meters"] = live_var.get()
            self.settings["meter_interval"] = int(interval_entry.get())
            self.settings["setup_geometry"] = win.geometry()
            self.save_settings()

            self.rig_profile = rigs.load_rig_profile(self.settings["radio_model"])
            self.log(f"🔄 Rig profile reloaded: {self.settings['radio_model']}")

            win.destroy()
            self.connect_serial()

        def test_connection():
            try:
                ser = serial.Serial(com_entry.get(), int(baud_entry.get()), timeout=1)
                ser.write(b"FA;")
                time.sleep(0.2)
                resp = ser.read(128).decode(errors="ignore").strip()
                ser.close()
                if resp.startswith("FA"):
                    hz = int(resp[2:].strip(";"))
                    mhz = hz / 1_000_000
                    msg = f"Connected, {mhz:.5f} MHz"
                    status_label.config(text=msg, fg="green")
                    self.settings["last_test_status"] = msg
                else:
                    msg = f"No valid response ({resp})"
                    status_label.config(text=msg, fg="red")
                    self.settings["last_test_status"] = msg
            except Exception as e:
                msg = f"Error: {e}"
                status_label.config(text=msg, fg="red")
                self.settings["last_test_status"] = msg
            self.save_settings()

        tk.Button(btns, text="Save", command=save_and_close).pack(side=tk.LEFT, padx=5)
        tk.Button(btns, text="Test Connection", command=test_connection).pack(side=tk.LEFT, padx=5)

    # ----------------- Utility methods -----------------
    def load_settings(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    data = json.load(f)
                    out = DEFAULT_SETTINGS.copy()
                    out.update(data)
                    return out
            except Exception:
                return DEFAULT_SETTINGS.copy()
        return DEFAULT_SETTINGS.copy()

    def save_settings(self):
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump(self.settings, f, indent=4)
            self.log("💾 Settings saved")
        except Exception as e:
            self.log(f"⚠️ Could not save settings: {e}")

    def on_close(self):
        try:
            self.settings["main_geometry"] = self.root.geometry()
            self.save_settings()
        except Exception:
            pass
        self.root.destroy()

    def log(self, msg):
        self.log_area.config(state="normal")
        self.log_area.insert(tk.END, msg + "\n")
        self.log_area.yview(tk.END)
        self.log_area.config(state="disabled")
        self.status_var.set(msg)

    def set_status_light(self, color):
        self.status_canvas.itemconfig(self.status_light, fill=color)

    def show_about(self):
        rig_name = self.settings.get("radio_model", "Unknown")
        messagebox.showinfo("About", f"{APP_TITLE} {APP_VERSION}\nActive Rig: {rig_name}")

    # ----------------- Serial + Commands -----------------
    def connect_serial(self):
        if getattr(self, "ser", None):
            try:
                self.ser.close()
            except Exception:
                pass
        try:
            self.ser = serial.Serial(self.settings["com_port"], self.settings["baud_rate"], timeout=1)
            msg = f"✅ Connected {self.settings['com_port']} @ {self.settings['baud_rate']}"
            self.log(msg)
            self.set_status_light("grey")
        except Exception as e:
            self.ser = None
            msg = f"❌ Could not open port {self.settings['com_port']}: {e}"
            self.log(msg)
            self.set_status_light("grey")

    def send_command(self, cmd):
        if not self.ser:
            self.log("❌ No serial connection")
            return ""
        try:
            self.ser.write(cmd.encode("ascii"))
            time.sleep(0.1)
            resp = self.ser.read(128).decode(errors="ignore").strip()
            self.log(f"➡️ Sent: {cmd.strip()}")
            if resp:
                self.log(f"⬅️ Received: {resp}")
            return resp
        except Exception as e:
            self.log(f"⚠️ Serial error: {e}")
            return ""

    def ptt_on(self):
        if not self.ser:
            self.log("❌ No serial connection")
            return
        power = self.settings.get("default_power", 50)
        cmd_power = self.rig_profile.get("set_power", "PC{value:03d};").format(value=power)
        self.send_command(cmd_power)
        cmd_ptt_on = self.rig_profile.get("ptt_on", "TX;")
        self.send_command(cmd_ptt_on)
        self.log(f"🔴 PTT ON (Power {power}%)")
        self.set_status_light("red")

    def ptt_off(self):
        if not self.ser:
            self.log("❌ No serial connection")
            return
        cmd = self.rig_profile.get("ptt_off", "RX;")
        self.send_command(cmd)
        self.log("🟢 PTT OFF")
        self.set_status_light("green")

    def read_frequency(self):
        cmd = self.rig_profile.get("get_freq", "FA;")
        resp = self.send_command(cmd)
        try:
            if resp.startswith("FA"):
                hz = int(resp[2:].strip(";"))
                mhz = hz / 1_000_000
                msg = f"📡 Frequency: {mhz:.5f} MHz"
                self.log(msg)
                self.status_var.set(msg)
        except Exception:
            self.log(f"⚠️ Could not parse frequency: {resp}")

    def read_swr(self):
        cmd_sel = self.rig_profile.get("read_swr_select", "RM5;")
        self.send_command(cmd_sel)
        time.sleep(0.05)
        cmd_val = self.rig_profile.get("read_meter_value", "RM;")
        resp = self.send_command(cmd_val)
        try:
            if resp.startswith("RM"):
                val = int(resp[2:].strip(";"))
                return val / 100.0
        except Exception:
            return None
        return None

    def read_meter(self, meter_id):
        cmd_sel = self.rig_profile.get("read_meter", "RM{meter};").format(meter=meter_id)
        self.send_command(cmd_sel)
        time.sleep(0.05)
        cmd_val = self.rig_profile.get("read_meter_value", "RM;")
        resp = self.send_command(cmd_val)
        try:
            if resp.startswith("RM"):
                val = int(resp[2:].strip(";"))
                return val
        except Exception:
            return None
        return None

    def update_meters(self):
        if not self.settings.get("live_meters", True):
            self.swr_label.config(text="SWR: --", fg="grey")
            self.power_label.config(text="Power: -- W", fg="grey")
            self.alc_label.config(text="ALC: --", fg="grey")
            self.root.after(1000, self.update_meters)
            return

        swr = self.read_swr()
        if swr:
            if swr <= 1.5:
                color = "green"
            elif swr <= 2.0:
                color = "orange"
            else:
                color = "red"
            self.swr_label.config(text=f"SWR: {swr:.2f}", fg=color)
            self.swr_history.append(swr)
            if len(self.swr_history) > 60:
                self.swr_history.pop(0)
            self.swr_line.set_xdata(range(len(self.swr_history)))
            self.swr_line.set_ydata(self.swr_history)
            self.swr_ax.set_ylim(1, max(3, max(self.swr_history) + 0.2))
            self.swr_canvas.draw()
        else:
            self.swr_label.config(text="SWR: --", fg="grey")

        power_raw = self.read_meter(1)
        if power_raw is not None:
            watts = round(power_raw * 0.1, 1)
            self.power_label.config(text=f"Power: {watts:.1f} W", fg="green" if watts < 90 else "red")
            self.power_history.append(watts)
            if len(self.power_history) > 60:
                self.power_history.pop(0)
            self.power_line.set_xdata(range(len(self.power_history)))
            self.power_line.set_ydata(self.power_history)
            self.power_ax.set_ylim(0, max(100, max(self.power_history) + 5))
            self.power_canvas.draw()
        else:
            self.power_label.config(text="Power: -- W", fg="grey")

        alc_raw = self.read_meter(2)
        if alc_raw is not None:
            alc = alc_raw / 10.0
            if alc < 30:
                color = "green"
            elif alc < 70:
                color = "orange"
            else:
                color = "red"
            self.alc_label.config(text=f"ALC: {alc:.1f}", fg=color)
        else:
            self.alc_label.config(text="ALC: --", fg="grey")

        interval_ms = self.settings.get("meter_interval", 1) * 1000
        self.root.after(interval_ms, self.update_meters)

    # ----------------- Tuning -----------------
    def toggle_tune(self):
        if not self.tune_active:
            self.start_tune()
        else:
            self.stop_tune()

    def start_tune(self):
        self.log("🎯 Starting tune...")
        self.tune_active = True
        self.tune_button.config(text="Stop Tune (F1)")
        swr_before = self.read_swr()
        if swr_before:
            self.log(f"SWR before tune: {swr_before:.2f}")
        self.ptt_on()
        self.root.after(self.settings.get("tune_time", 3) * 1000, self.stop_tune)

    def stop_tune(self):
        self.ptt_off()
        swr_after = self.read_swr()
        if swr_after:
            self.log(f"SWR after tune: {swr_after:.2f}")
        self.tune_active = False
        self.tune_button.config(text="Start Tune (F1)")
        self.log("✅ Tune cycle completed")

    def hard_tune(self):
        self.log("⚡ Hard Tune invoked")
        self.start_tune()

    def toggle_meters(self):
        if self.meter_frame.winfo_manager():
            self.meter_frame.pack_forget()
            self.meter_toggle_btn.config(text="Show Meters")
            self.settings["meters_visible"] = False
        else:
            self.meter_frame.pack()
            self.meter_toggle_btn.config(text="Hide Meters")
            self.settings["meters_visible"] = True
        self.save_settings()


# ----------------- Start -----------------
if __name__ == "__main__":
    root = tk.Tk()
    app = ReminTuneApp(root)
    root.mainloop()
