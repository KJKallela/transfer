
import tkinter as tk
from tkinter import ttk, messagebox
try:
    from serial.tools import list_ports
except Exception:
    list_ports = None
try:
    import serial
except Exception:
    serial = None

from settings import load_settings, save_settings

MODE_MAP = {
    'CW (MD03)': 'MD03',
    'USB (MD02)': 'MD02',
    'LSB (MD01)': 'MD01',
    'AM (MD05)': 'MD05',
    'FM (MD06)': 'MD06',
    'DIGI-U (MD09)': 'MD09',
    'DIGI-L (MD08)': 'MD08',
    'RTTY-U (MD11)': 'MD11',
    'RTTY-L (MD10)': 'MD10',
}

class SetupDialog(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("ReminTune — Setup")
        self.resizable(False, False)
        self.grab_set()

        s = load_settings()

        frm = ttk.Frame(self, padding=12); frm.grid(row=0, column=0, sticky="nsew")

        ttk.Label(frm, text="COM Port:").grid(row=0, column=0, sticky="w")
        self.port_var = tk.StringVar(value=s.get("com_port", ""))
        self.port_combo = ttk.Combobox(frm, textvariable=self.port_var, width=24, state="readonly")
        self._refresh_ports()
        self.port_combo.grid(row=0, column=1, sticky="ew", padx=6, pady=4)
        ttk.Button(frm, text="Refresh", command=self._refresh_ports).grid(row=0, column=2, padx=4)

        ttk.Label(frm, text="Baud rate:").grid(row=1, column=0, sticky="w")
        self.baud_var = tk.StringVar(value=str(s.get("baudrate", 9600)))
        self.baud_combo = ttk.Combobox(frm, textvariable=self.baud_var, values=[4800,9600,19200,38400,57600,115200], width=24, state="readonly")
        self.baud_combo.grid(row=1, column=1, sticky="ew", padx=6, pady=4)

        ttk.Label(frm, text="Rig:").grid(row=2, column=0, sticky="w")
        self.rig_var = tk.StringVar(value=s.get("rig", "FT-710"))
        self.rig_combo = ttk.Combobox(frm, textvariable=self.rig_var, values=["FT-710","IC-7100"], width=24, state="readonly")
        self.rig_combo.grid(row=2, column=1, sticky="ew", padx=6, pady=4)

        self.auto_var = tk.BooleanVar(value=bool(s.get("auto_detect_rig", False)))
        ttk.Checkbutton(frm, text="Auto-detect rig on connect", variable=self.auto_var).grid(row=3, column=1, sticky="w", padx=6, pady=2)

        ttk.Label(frm, text="Preferred mode:").grid(row=4, column=0, sticky="w")
        mkeys = list(MODE_MAP.keys())
        current_mode_code = s.get("preferred_mode", "MD03")
        current_mode_label = next((k for k,v in MODE_MAP.items() if v==current_mode_code), mkeys[0])
        self.mode_var = tk.StringVar(value=current_mode_label)
        self.mode_combo = ttk.Combobox(frm, textvariable=self.mode_var, values=mkeys, width=24, state="readonly")
        self.mode_combo.grid(row=4, column=1, sticky="ew", padx=6, pady=4)

        ttk.Label(frm, text="Tune power (W):").grid(row=5, column=0, sticky="w")
        self.power_var = tk.IntVar(value=int(s.get("tune_power_w", 20)))
        ttk.Spinbox(frm, textvariable=self.power_var, from_=1, to=100, increment=1, width=6).grid(row=5, column=1, sticky="w", padx=6, pady=4)

        ttk.Label(frm, text="Hard tune time (s):").grid(row=6, column=0, sticky="w")
        self.htime_var = tk.IntVar(value=int(s.get("hard_tune_sec", 4)))
        ttk.Spinbox(frm, textvariable=self.htime_var, from_=1, to=20, increment=1, width=6).grid(row=6, column=1, sticky="w", padx=6, pady=4)

        ttk.Label(frm, text="LCD theme:").grid(row=7, column=0, sticky="w")
        self.lcd_theme_var = tk.StringVar(value=s.get("lcd_theme","amber"))
        self.lcd_theme_combo = ttk.Combobox(frm, textvariable=self.lcd_theme_var, values=["amber","green"], width=24, state="readonly")
        self.lcd_theme_combo.grid(row=7, column=1, sticky="ew", padx=6, pady=4)

        self.lcd_seg_var = tk.BooleanVar(value=bool(s.get("use_7seg_lcd", True)))
        ttk.Checkbutton(frm, text="Use 7‑segment LCD", variable=self.lcd_seg_var).grid(row=8, column=1, sticky="w", padx=6, pady=2)

        self.auto_log_var = tk.BooleanVar(value=bool(s.get("auto_log", False)))
        ttk.Checkbutton(frm, text="Auto-save session log", variable=self.auto_log_var).grid(row=9, column=1, sticky="w", padx=6, pady=2)

        btn = ttk.Frame(frm); btn.grid(row=10, column=0, columnspan=3, sticky="e", pady=(8,0))
        ttk.Button(btn, text="Test Connection", command=self._test_connection).pack(side="left", padx=6)
        ttk.Button(btn, text="Reset SWR Meter", command=self._reset_swr_meter).pack(side="left", padx=6)
        ttk.Button(btn, text="Save", command=self._on_save).pack(side="right")
        ttk.Button(btn, text="Cancel", command=self.destroy).pack(side="right", padx=6)

        self.bind("<Return>", lambda e: self._on_save())
        self.bind("<Escape>", lambda e: self.destroy())

    def _report_to_main(self, msg: str):
        try:
            if hasattr(self.master, "_log"):
                self.master._log(msg)
            if hasattr(self.master, "status"):
                try: self.master.status.set(msg)
                except Exception: pass
        except Exception:
            pass

    def _refresh_ports(self):
        if list_ports:
            ports = [p.device for p in list_ports.comports()]
        else:
            ports = []
        if not ports:
            ports = ["COM1","COM2","COM3","COM4"]
        self.port_combo["values"] = ports
        if self.port_var.get() not in ports:
            self.port_var.set(ports[0])

    def _on_save(self):
        try:
            baud = int(self.baud_var.get())
        except ValueError:
            messagebox.showerror("Invalid baud rate", "Please choose a numeric baud rate.")
            return
        data = {
            "com_port": self.port_var.get().strip(),
            "baudrate": baud,
            "rig": self.rig_var.get().strip(),
            "auto_detect_rig": bool(self.auto_var.get()),
            "preferred_mode": MODE_MAP.get(self.mode_var.get(), "MD03"),
            "tune_power_w": int(self.power_var.get() or 20),
            "tune_power_pct": int(self.power_var.get() or 20),
            "tune_mode": (self.mode_var.get().split()[0] if self.mode_var.get() else "CW"),
            "hard_tune_sec": int(self.htime_var.get() or 4),
            "lcd_theme": self.lcd_theme_var.get(),
            "use_7seg_lcd": bool(self.lcd_seg_var.get()),
            "auto_log": bool(self.auto_log_var.get()),
        }
        ok = save_settings(data)
        if ok:
            messagebox.showinfo("Saved", "Settings saved. They will persist for next launch.")
            self.destroy()
        else:
            messagebox.showerror("Save failed", "Could not save settings. Check file permissions.")

    def _test_connection(self):
        try:
            from serial.tools import list_ports as _
        except Exception:
            pass
        try:
            import serial as _
        except Exception:
            pass
        try:
            baud = int(self.baud_var.get())
        except Exception:
            baud = 9600
        port = self.port_var.get().strip()
        rig = self.rig_var.get().strip()
        try:
            import serial
        except Exception:
            serial = None
        if serial is None:
            messagebox.showerror("Serial not available", "pyserial is not installed.")
            self._report_to_main("[Test] Serial not available (pyserial not installed)")
            return
        try:
            with serial.Serial(port=port, baudrate=baud, timeout=1) as ser:
                if rig == "FT-710":
                    ser.write(b"AC;")
                    raw = ser.read(32)
                    msg = f"[Test] OK: Opened {port} @ {baud} | Tuner status reply: {raw!r}"
                    messagebox.showinfo("Connection OK", msg)
                    self._report_to_main(msg)
                else:
                    ser.write(bytes.fromhex("FEFE88E006FD"))
                    raw = ser.read(32)
                    msg = f"[Test] OK: Opened {port} @ {baud} | Mode reply (hex): {raw.hex().upper()}"
                    messagebox.showinfo("Connection OK", msg)
                    self._report_to_main(msg)
        except Exception as e:
            emsg = f"[Test] Connection failed: {e}"
            messagebox.showerror("Connection failed", f"Could not communicate with rig.\n{e}")
            self._report_to_main(emsg)

    def _reset_swr_meter(self):
        try:
            if hasattr(self.master, "_log"):
                self.master._log("[SWR] meter reset by user")
            if hasattr(self.master, "status"):
                self.master.status.set("SWR meter reset")
        except Exception:
            pass
