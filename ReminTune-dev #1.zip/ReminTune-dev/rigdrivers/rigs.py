
import time

def ic7100_tune(ser, settings, duration_s: float | None = None):
    # CI-V tune sequence for IC-7100 (addr 0x88)
    def send(cmd: bytes): ser.write(b"\xFE\xFE\x88\xE0" + cmd + b"\xFD")
    tune_power = int(settings.get("tune_power_w", 20))
    pwr_val = max(1, min(100, tune_power))
    pwr_byte = int(pwr_val * 255 / 100).to_bytes(1, "little")
    mode_map = {
        "MD03": b"\x01\x00",  # CW
        "MD02": b"\x00\x01",  # USB
        "MD01": b"\x00\x00",  # LSB
        "MD05": b"\x02\x00",  # AM
        "MD06": b"\x03\x00",  # FM
        "MD09": b"\x07\x00",  # DIGI-U
        "MD08": b"\x06\x00",  # DIGI-L
        "MD11": b"\x09\x00",  # RTTY-U
        "MD10": b"\x08\x00",  # RTTY-L
    }
    pm = settings.get("preferred_mode", "MD03")
    send(b"\x14" + pwr_byte + b"\x00\x00\x00")  # power
    send(b"\x06" + mode_map.get(pm, b"\x01\x00"))  # mode
    send(b"\x1C\x00")  # TX on
    time.sleep(float(duration_s) if duration_s is not None else 2.0)
    send(b"\x1C\x01")  # TX off
    send(b"\x14\x64\x00\x00\x00")  # restore 100%

def ft710_tune(ser, settings, duration_s: float | None = None):
    # Yaesu FT-710 CAT tune
    tune_power = int(settings.get("tune_power_w", 20))
    pct = max(1, min(100, int(tune_power)))
    pm = settings.get("preferred_mode", "MD03")
    md = pm[-2:] if isinstance(pm, str) and len(pm) >= 4 else "03"
    ser.write(f"MD{md};".encode("ascii"))
    ser.write(f"PC{pct:03d};".encode("ascii"))
    time.sleep(0.2)
    ser.write(b"TX1;")
    time.sleep(0.2)
    ser.write(b"AC002;")
    time.sleep(float(duration_s) if duration_s is not None else 4.0)
    ser.write(b"TX0;")
    ser.write(b"PC100;")

RIG_MAP = {
    "IC-7100": ic7100_tune,
    "FT-710": ft710_tune,
}
