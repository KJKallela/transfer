# ReminTune Changelog

## 1.2.26 RC4e
- FT-710: Full hard tune wrap — save mode/power, switch to CW+10W, key TX, start tuner, wait, unkey, restore power and mode.
- Always restore original settings even if the sequence fails.
- Logs each command and the raw replies.
- Version string bumped to RC4e.
