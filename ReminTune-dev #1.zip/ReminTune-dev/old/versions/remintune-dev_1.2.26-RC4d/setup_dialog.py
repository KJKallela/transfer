# setup_dialog.py
import tkinter as tk
from tkinter import ttk
from settings import save_settings

class SetupDialog(tk.Toplevel):
    def __init__(self, parent, current_settings):
        super().__init__(parent)
        self.title("Setup")
        self.resizable(False, False)
        self.result = None

        frm = ttk.Frame(self, padding=10)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="COM Port").grid(row=0, column=0, sticky="w")
        self.com_port = tk.StringVar(value=current_settings.get("com_port", "COM3"))
        ttk.Entry(frm, textvariable=self.com_port, width=12).grid(row=0, column=1, sticky="w")

        ttk.Label(frm, text="Baudrate").grid(row=1, column=0, sticky="w", pady=(6,0))
        self.baud = tk.StringVar(value=str(current_settings.get("baudrate", 9600)))
        ttk.Entry(frm, textvariable=self.baud, width=12).grid(row=1, column=1, sticky="w", pady=(6,0))

        ttk.Label(frm, text="Rig").grid(row=2, column=0, sticky="w", pady=(6,0))
        self.rig = tk.StringVar(value=current_settings.get("rig", "FT-710"))
        ttk.Entry(frm, textvariable=self.rig, width=14).grid(row=2, column=1, sticky="w", pady=(6,0))

        btns = ttk.Frame(frm)
        btns.grid(row=3, column=0, columnspan=2, sticky="e", pady=(12,0))
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=(6,0))
        ttk.Button(btns, text="Save", command=self._on_save).pack(side="right")

        self.bind("<Return>", lambda e: self._on_save())
        self.bind("<Escape>", lambda e: self.destroy())

    def _on_save(self):
        self.result = {
            "com_port": self.com_port.get().strip(),
            "baudrate": int(self.baud.get().strip() or "0"),
            "rig": self.rig.get().strip() or "FT-710",
            "auto_detect_rig": False
        }
        save_settings(self.result)
        self.destroy()
