# rigs.py
import json, os, time, re
from typing import Optional, Tuple, List

def _is_hex(s: str) -> bool:
    s = s.strip()
    if s.endswith(';'):
        return False  # ASCII CAT
    return bool(re.fullmatch(r"[0-9A-Fa-f]+", s)) and len(s) % 2 == 0

class RigBase:
    def __init__(self, session, rig_name: str):
        self.session = session
        self.rig_name = rig_name
        self.protocol = "unknown"
        self._cmds = {}

    def load_commands(self) -> None:
        json_path = os.path.join(os.path.dirname(__file__), "rigs.json")
        rigs = json.loads(open(json_path, "r", encoding="utf-8").read())
        if self.rig_name in rigs:
            conf = rigs[self.rig_name]
            self.protocol = conf.get("protocol", "unknown")
            self._cmds = conf
        else:
            raise RuntimeError(f"Rig '{self.rig_name}' not found in rigs.json")

    def _send_key(self, key: str) -> None:
        if key not in self._cmds:
            raise KeyError(f"Command '{key}' not defined for rig {self.rig_name}")
        cmd = self._cmds[key]
        self._send_any(cmd)

    def _send_any(self, cmd: str) -> None:
        if _is_hex(cmd) or self.protocol == "icom":
            self.session.send_bytes(bytes.fromhex(cmd))
        else:
            self.session.send(cmd if cmd.endswith(';') else (cmd + ';'))

    def _run_sequence(self, seq: List[str]) -> None:
        for step in seq:
            st = step.strip()
            if st.upper().startswith("DELAY "):
                try:
                    ms = int(st.split()[1])
                except Exception:
                    ms = 200
                if self.session and self.session.logger:
                    self.session.logger(f"(DELAY {ms}ms)")
                time.sleep(ms / 1000.0)
            else:
                self._send_any(st)
                if st.upper().startswith("TX1"):
                    if self.session and self.session.logger:
                        self.session.logger("(TX started)")
                elif st.upper().startswith("TX0"):
                    if self.session and self.session.logger:
                        self.session.logger("(TX stopped)")

    def get_tuner_status(self) -> Tuple[Optional[bool], str]:
        if "tuner_status" not in self._cmds:
            return (None, "")
        if self.protocol == "yaesu":
            self._send_any(self._cmds["tuner_status"])
            raw = self.session.read_ascii_until(';', timeout=1.0).strip()
            ru = raw.upper()
            is_on = True if "AC001" in ru or "AC002" in ru else (False if "AC000" in ru else None)
            return (is_on, raw)
        else:
            self._send_any(self._cmds["tuner_status"])
            raw_bytes = self.session.read_bytes_until_fd(timeout=1.0)
            return (None, raw_bytes.hex().upper())

    def tuner_on(self): self._send_key("tuner_on")
    def tuner_off(self): self._send_key("tuner_off")
    def tuner_start(self):
        if "tuner_start_seq" in self._cmds:
            self._run_sequence(self._cmds["tuner_start_seq"])
        else:
            self._send_key("tuner_start")

class YaesuFT710(RigBase):
    def __init__(self, session):
        super().__init__(session, "FT-710")
        self.load_commands()

class IcomIC7100(RigBase):
    def __init__(self, session):
        super().__init__(session, "IC-7100")
        self.load_commands()
