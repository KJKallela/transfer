# main.py
import os
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from typing import Optional

from civ import CIVSession
from rigs import YaesuFT710, IcomIC7100, RigBase
from setup_dialog import SetupDialog
from settings import load_settings, save_settings

APP_VER = "ReminTune v1.2.26 RC4d"
ASCII_LOGO = os.path.join(os.path.dirname(__file__), "ASCII_LOGO.txt")

class ReminTuneApp:
    def __init__(self) -> None:
        self._print_logo()

        self.root = tk.Tk()
        self.root.title(APP_VER)
        self.settings = load_settings()
        self.session: Optional[CIVSession] = None
        self.rig: Optional[RigBase] = None
        self.tuner_enabled: Optional[bool] = None

        self._build_ui()
        self._update_status("disconnected")

    def _build_ui(self) -> None:
        top = ttk.Frame(self.root)
        top.pack(fill="x", padx=10, pady=8)

        self.connect_btn = ttk.Button(top, text="Connect", command=self._on_connect_toggle)
        self.connect_btn.pack(side="left")

        self.status_canvas = tk.Canvas(top, width=16, height=16, highlightthickness=0)
        self.status_canvas.pack(side="left", padx=8)
        self.status_oval = self.status_canvas.create_oval(2,2,14,14, fill="red", outline="black")

        ttk.Button(top, text="Setup…", command=self._open_setup).pack(side="left", padx=6)

        self.btn_toggle = ttk.Button(top, text="Tune On", command=self._on_tuner_toggle, state="disabled")
        self.btn_toggle.pack(side="left", padx=6)

        self.btn_hard = ttk.Button(top, text="Hard Tune", command=self._on_tuner_start, state="disabled")
        self.btn_hard.pack(side="left", padx=6)

        self.log = scrolledtext.ScrolledText(self.root, height=18, wrap="word")
        self.log.pack(fill="both", expand=True, padx=10, pady=8)

        self.status_lbl = ttk.Label(self.root, text="Ready.")
        self.status_lbl.pack(fill="x", padx=10, pady=(0,8))

    def _print_logo(self):
        try:
            print(open(ASCII_LOGO, "r", encoding="utf-8").read())
        except Exception:
            print("ReminTune")
        print(APP_VER)
        print("=" * len(APP_VER))

    def _log(self, msg: str):
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        print(msg)

    def _set_status_color(self, state: str):
        self.status_canvas.itemconfig(self.status_oval, fill={
            "disconnected":"red", "connecting":"yellow", "connected":"green"
        }.get(state, "red"))

    def _update_status(self, state: str):
        self._set_status_color(state)
        s = self.settings
        txt = f"{state.title()} | Rig: {s.get('rig')} | Port: {s.get('com_port')} @ {s.get('baudrate')}"
        self.status_lbl.config(text=txt)
        enable = (state == "connected")
        self.btn_toggle.config(state=("normal" if enable else "disabled"))
        self.btn_hard.config(state=("normal" if enable else "disabled"))

    def _init_rig(self):
        name = self.settings.get("rig", "FT-710")
        if name == "FT-710":
            self.rig = YaesuFT710(self.session)
        elif name == "IC-7100":
            self.rig = IcomIC7100(self.session)
        else:
            self.rig = YaesuFT710(self.session)
        self._log(f"Loaded rig config for {name} (protocol: {self.rig.protocol})")

    def _apply_tuner_label(self):
        self.btn_toggle.config(text=("Tune Off" if self.tuner_enabled else "Tune On"))

    def _open_setup(self):
        dlg = SetupDialog(self.root, self.settings)
        self.root.wait_window(dlg)
        if getattr(dlg, "result", None):
            self.settings.update(dlg.result)
            save_settings(self.settings)
            self._log(f"Settings saved: {self.settings}")
            if self.session and self.session.is_open:
                self._init_rig()
                try:
                    is_on, raw = self.rig.get_tuner_status()
                    self._log(f"Raw tuner status reply: {raw}")
                    self.tuner_enabled = is_on
                    self._log(f"Tuner is {'ON' if is_on else 'OFF' if is_on is not None else 'UNKNOWN'}")
                    self._apply_tuner_label()
                except Exception as e:
                    self._log(f"Tuner status query failed: {e}")
            self._update_status("connected" if (self.session and self.session.is_open) else "disconnected")

    def _on_connect_toggle(self):
        if self.session and self.session.is_open:
            try:
                self.session.close()
                self._log("Disconnected.")
            except Exception as e:
                messagebox.showerror("Disconnect error", str(e))
            finally:
                self.connect_btn.config(text="Connect")
                self._update_status("disconnected")
            return

        port = self.settings.get("com_port", "")
        baud = int(self.settings.get("baudrate", 9600))
        if not port:
            messagebox.showerror("Missing COM port", "Please configure COM Port in Setup.")
            return
        try:
            self._update_status("connecting")
            self.session = CIVSession(logger=self._log)
            self.session.open(port, baud)
            self._init_rig()
            self._log(f"Connected to {port} @ {baud}")
            self.connect_btn.config(text="Disconnect")
            self._update_status("connected")
            try:
                is_on, raw = self.rig.get_tuner_status()
                self._log(f"Raw tuner status reply: {raw}")
                self.tuner_enabled = is_on
                self._log(f"Tuner is {'ON' if is_on else 'OFF' if is_on is not None else 'UNKNOWN'}")
                self._apply_tuner_label()
            except Exception as e:
                self._log(f"Tuner status query failed: {e}")
                self.tuner_enabled = None
                self._apply_tuner_label()
        except Exception as e:
            self._log(f"Connection error: {e}")
            messagebox.showerror("Connection error", str(e))
            self._update_status("disconnected")

    def _on_tuner_toggle(self):
        if not self.rig:
            messagebox.showwarning("No rig", "Connect to a rig first.")
            return
        try:
            if self.tuner_enabled is True:
                self.rig.tuner_off()
                self.tuner_enabled = False
                self._log("Sent tuner OFF")
            else:
                self.rig.tuner_on()
                self.tuner_enabled = True
                self._log("Sent tuner ON")
            self._apply_tuner_label()
        except Exception as e:
            messagebox.showerror("Tuner toggle error", str(e))
            self._update_status("connecting")

    def _on_tuner_start(self):
        if not self.rig:
            messagebox.showwarning("No rig", "Connect to a rig first.")
            return
        try:
            self.status_lbl.config(text="Hard Tune in progress…")
            self.btn_toggle.config(state="disabled")
            self.btn_hard.config(state="disabled")

            self.rig.tuner_start()

            self._log("✅ Hard Tune complete (rig: %s)" % self.settings.get("rig"))
        except Exception as e:
            messagebox.showerror("Hard tune error", str(e))
        finally:
            self._update_status("connected" if (self.session and self.session.is_open) else "disconnected")

    def run(self):
        self.root.mainloop()

def main():
    ReminTuneApp().run()

if __name__ == "__main__":
    main()
