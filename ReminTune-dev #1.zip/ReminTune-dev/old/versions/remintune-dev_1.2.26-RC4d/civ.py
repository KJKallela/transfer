# civ.py
from typing import Optional, Callable
import time
try:
    import serial
except Exception:
    serial = None

class CIVSession:
    def __init__(self, logger: Optional[Callable[[str], None]] = None):
        self.ser: Optional['serial.Serial'] = None
        self.logger = logger

    @property
    def is_open(self) -> bool:
        return bool(self.ser and self.ser.is_open)

    def open(self, port: str, baud: int) -> None:
        if serial is None:
            raise RuntimeError("pyserial is not installed. pip install pyserial")
        self.close()
        try:
            self.ser = serial.Serial(port=port, baudrate=baud, timeout=0.2, write_timeout=0.5)
            if self.logger: self.logger(f"Serial opened: {port} @ {baud}")
        except Exception:
            self.ser = None
            raise

    def close(self) -> None:
        if self.ser:
            try: self.ser.close()
            finally: self.ser = None

    def send(self, cmd: str) -> None:
        if not self.is_open: raise RuntimeError("Port not open")
        if self.logger: self.logger(f">> {cmd.strip()}")
        self.ser.write(cmd.encode("ascii")); self.ser.flush()

    def send_bytes(self, data: bytes) -> None:
        if not self.is_open: raise RuntimeError("Port not open")
        if self.logger: self.logger(f">> {data.hex().upper()}")
        self.ser.write(data); self.ser.flush()

    def read_ascii_until(self, terminator: str = ';', timeout: float = 1.0) -> str:
        if not self.is_open: raise RuntimeError("Port not open")
        end = time.time() + timeout
        buf = bytearray(); t = terminator.encode("ascii")
        while time.time() < end:
            b = self.ser.read(1)
            if b:
                if b == t: break
                buf.extend(b)
            else:
                time.sleep(0.01)
        data = buf.decode(errors="ignore")
        if self.logger and data: self.logger(f"<< {data}")
        return data

    def read_bytes_until_fd(self, timeout: float = 1.0) -> bytes:
        if not self.is_open: raise RuntimeError("Port not open")
        end = time.time() + timeout
        buf = bytearray()
        while time.time() < end:
            b = self.ser.read(1)
            if b:
                buf.extend(b)
                if b == b'\xFD': break
            else:
                time.sleep(0.01)
        if self.logger and buf: self.logger(f"<< {buf.hex().upper()}")
        return bytes(buf)
