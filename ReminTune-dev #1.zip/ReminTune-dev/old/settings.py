# settings.py
import json
from pathlib import Path
from typing import Any
DEFAULTS: dict[str, Any] = {"com_port":"COM3","baudrate":9600,"rig":"FT-710","auto_detect_rig":False}
SETTINGS_FILE = Path(__file__).with_name("settings.json")
def load_settings(path: Path | None = None) -> dict[str, Any]:
    path = path or SETTINGS_FILE
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if "port" in data and "com_port" not in data: data["com_port"]=data.pop("port")
        if "baud" in data and "baudrate" not in data: data["baudrate"]=data.pop("baud")
    except Exception: data = {}
    out = DEFAULTS.copy(); out.update(data); return out
def save_settings(s: dict[str, Any], path: Path | None = None) -> bool:
    path = path or SETTINGS_FILE
    try:
        path.write_text(json.dumps(s, indent=2), encoding="utf-8"); return True
    except Exception as e:
        print(f"Failed to save settings: {e}"); return False
