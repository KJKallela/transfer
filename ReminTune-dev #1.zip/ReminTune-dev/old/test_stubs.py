# test_stubs.py
from civ import CIVSession, make_civ_frame
from smeter import parse_smeter_from_reply
def test_civ():
    print("=== Testing CIVSession ===")
    log=lambda msg: print(f"[LOG] {msg}")
    session=CIVSession(logger=log); session.open("COM3",9600); session.send(b"\x01\x02\x03")
    frame=make_civ_frame(b"\x01\x02"); print(f"Generated frame: {frame.hex().upper()}"); session.close()
def test_smeter():
    print("\n=== Testing S-meter parser ===")
    reply=b"\xfe\xfe\x01\x02\xfd"+bytes([123])
    level=parse_smeter_from_reply(reply); print(f"Parsed S-meter level: {level}")
if __name__=="__main__": test_civ(); test_smeter()
