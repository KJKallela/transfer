# ReminTune

ReminTune is a multi-rig control and tuner interface for radios such as the Icom IC-7100 and Yaesu FT-710.  
It provides a Tkinter-based GUI, rig setup dialog, and extensible rig communication via CI-V and other protocols.

## ✨ Features
- Multi-rig support (Auto / IC-7100 / FT-710)
- Auto-detect rig option
- Setup dialog with:
  - COM port dropdown (with Refresh)
  - Baudrate dropdown (common speeds 300–921600 bps)
- CI-V session with logger support
- S-meter parsing stub
- Settings persistence (`settings.json`)
- Test stubs for quick verification

## 🚀 Getting Started
### Prerequisites
- Python 3.9+  
- Tkinter (usually bundled with Python)  
- PySerial (`pip install pyserial`)

### Run
```bash
python main.py
```

### Test
```bash
python test_stubs.py
```

## 🛠 Development
- Version control managed with Git
- Tags mark stable checkpoints (`final31`, `final32`, …)

## 📜 License
See [LICENSE](LICENSE).
