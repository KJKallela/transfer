# smeter.py
def parse_smeter_from_reply(reply: bytes) -> int:
    if not reply: return 0
    try: return reply[-1]
    except Exception: return 0
