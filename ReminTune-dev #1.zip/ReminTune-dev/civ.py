
from __future__ import annotations
from typing import Optional
import time, binascii

class CIVSession:
    def __init__(self, logger=None):
        self.ser = None
        self.owner = None
        self._logger = logger

    @property
    def is_open(self) -> bool:
        try:
            return bool(self.ser and getattr(self.ser, "is_open", True))
        except Exception:
            return False

    def open(self, port: str, baud: int):
        import serial
        self.ser = serial.Serial(port=port, baudrate=baud, timeout=1)

    def close(self):
        try:
            if self.ser and getattr(self.ser, "is_open", True):
                self.ser.close()
        except Exception:
            pass
        self.ser = None

    def send_ascii(self, s: str):
        if self._logger: self._logger(f">> {s.strip()}")
        self.ser.write(s.encode("ascii"))

    def read_ascii_until(self, term=';', timeout=1.0) -> str:
        end = time.time() + float(timeout)
        out = bytearray()
        while time.time() < end:
            b = self.ser.read(1)
            if not b:
                break
            out += b
            if b == term.encode("ascii"):
                break
        s = out.decode("ascii", errors="ignore")
        if self._logger and s:
            self._logger(f"<< {s.strip()}")
        return s

    @staticmethod
    def _hex_to_bytes(hex_string: str) -> bytes:
        s = hex_string.replace(" ", "").replace("\n", "")
        return binascii.unhexlify(s)

    def send_hex(self, hex_string: str):
        data = self._hex_to_bytes(hex_string)
        if self._logger: self._logger(f">> {hex_string.strip()}")
        self.ser.write(data)

    def read_bytes_until_fd(self, timeout=1.0) -> bytes:
        end = time.time() + float(timeout)
        out = bytearray()
        while time.time() < end:
            b = self.ser.read(1)
            if not b:
                break
            out += b
            if b == b'\xFD':
                break
        if self._logger and out:
            self._logger(f"<< {out.hex(' ').upper()}")
        return bytes(out)
