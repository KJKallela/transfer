import os
import json

RIGS_DIR = os.path.join(os.path.dirname(__file__), "rigs")


def load_rig_profile(model: str) -> dict:
    """
    Load rig profile by friendly name (from JSON "name") or filename.
    """
    if not model:
        return {}

    for f in os.listdir(RIGS_DIR):
        if not f.endswith(".json"):
            continue
        path = os.path.join(RIGS_DIR, f)
        try:
            with open(path, "r", encoding="utf-8") as jf:
                data = json.load(jf)
                # Match friendly name
                if data.get("name") == model:
                    return data
                # Match by filename (case/space insensitive)
                base = os.path.splitext(f)[0]
                if base.lower() == model.lower().replace(" ", "").replace("-", ""):
                    return data
        except Exception as e:
            print(f"⚠️ Error loading {f}: {e}")
            continue

    print(f"⚠️ Rig profile not found for: {model}")
    return {}


# ----------------- Self-test -----------------
if __name__ == "__main__":
    print("🔍 Scanning rig profiles in:", RIGS_DIR)
    if not os.path.exists(RIGS_DIR):
        print("❌ rigs/ directory not found!")
        exit(1)

    files = [f for f in os.listdir(RIGS_DIR) if f.endswith(".json")]
    if not files:
        print("❌ No JSON rig profiles found in rigs/")
        exit(1)

    for f in files:
        path = os.path.join(RIGS_DIR, f)
        try:
            with open(path, "r", encoding="utf-8") as jf:
                data = json.load(jf)
                print(f"✅ Loaded {f} -> Name: {data.get('name', '(no name field)')}")
        except Exception as e:
            print(f"⚠️ Could not parse {f}: {e}")

    # Try loading default profile
    print("\nTesting default load (Yaesu FT-710)...")
    profile = load_rig_profile("Yaesu FT-710")
    if profile:
        print("✅ Profile loaded OK")
    else:
        print("❌ Could not load default profile")
