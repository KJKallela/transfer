
from __future__ import annotations
import re, time
from typing import Optional, Tuple, Dict, Any

class Rig:
    def __init__(self, session, profile: Dict[str, Any]):
        self.session = session
        self.profile = profile or {}
        self.cmds: Dict[str, str] = (self.profile.get("commands") or {})

    def _owner_settings(self) -> Dict[str, Any]:
        try:
            owner = getattr(self.session, 'owner', None)
            if owner and hasattr(owner, 'settings'):
                return dict(owner.settings)
        except Exception:
            pass
        return {}

    def _send(self, key: str, **kwargs) -> None:
        cmd = (self.cmds or {}).get(key)
        if not cmd:
            return
        try:
            cmd_fmt = cmd.format(**kwargs)
        except Exception:
            cmd_fmt = cmd
        if cmd_fmt.endswith(';'):
            self.session.send_ascii(cmd_fmt)
        else:
            self.session.send_hex(cmd_fmt)

    def _send_power(self, key_name: str, value: int):
        cmd = (self.cmds or {}).get(key_name)
        if not cmd: 
            return
        if '{pct}' in cmd:
            self._send(key_name, pct=f"{int(value):03d}")
        elif '{power}' in cmd:
            self._send(key_name, power=f"{int(value):03d}")
        else:
            self._send(key_name, pct=f"{int(value):03d}")

    def _read_ascii_until(self, term=';', timeout=1.0) -> str:
        raw = self.session.read_ascii_until(term, timeout=timeout) or ""
        return raw.strip()

    def _read_mode(self) -> Optional[str]:
        get = (self.cmds or {}).get("get_mode")
        if not get: 
            return None
        if get.endswith(';'):
            self.session.send_ascii(get)
            raw = self._read_ascii_until(';', timeout=0.7).upper()
            if raw.strip() == '?' or not raw:
                # fallback: Yaesu often echoes current without question forms
                self.session.send_ascii('MD0;')
                raw = self._read_ascii_until(';', timeout=0.7).upper()
            m = re.search(r"MD([0-9A-F]{2})", raw)
            return m.group(1) if m else None
        else:
            # CIV/hex path not implemented in this minimal profile
            return None

    def _read_power(self) -> Optional[int]:
        get = (self.cmds or {}).get("get_power")
        if not get: 
            return None
        if get.endswith(';'):
            self.session.send_ascii(get)
            raw = self._read_ascii_until(';', timeout=0.7)
            m = re.search(r"PC\s*([0-9]{1,3})", (raw or "").upper())
            if m:
                try: 
                    return int(m.group(1))
                except Exception: 
                    return None
            m2 = re.search(r"([0-9]{1,3})", raw or "")
            return int(m2.group(1)) if m2 else None
        else:
            return None

    def _read_swr(self) -> Optional[float]:
        get = (self.cmds or {}).get("get_swr")
        if not get: 
            return None
        if get.endswith(';'):
            self.session.send_ascii(get)
            raw = self.session.read_ascii_until(';', timeout=1.0) or ""
            ru = (raw or "").strip().upper()
            if not ru:
                try:
                    extra = self.session.read_ascii_until(';', timeout=0.2) or ""
                    ru = (extra or "").strip().upper()
                except Exception:
                    ru = ""
            # float form
            m = re.search(r"([0-9]+\\.[0-9]+)", ru)
            if m:
                try: 
                    return float(m.group(1))
                except Exception: 
                    pass
            # raw digits form (RM5xxxxx)
            if ru.startswith("RM5"):
                digits = "".join(ch for ch in ru[3:] if ch.isdigit())
                if len(digits) >= 3:
                    try:
                        val = int(digits[-3:])
                        swr = 1.0 if val <= 1 else round(1.0 + (val / 160.0), 2)
                        try:
                            owner = getattr(self.session, "owner", None)
                            if owner and hasattr(owner, "_log"):
                                owner._log(f"[SWR meter raw] {val}")
                        except Exception:
                            pass
                        return swr
                    except Exception:
                        return None
            # fallback integer scale
            m2 = re.search(r"([0-9]{1,4})", ru)
            if m2:
                try:
                    val = int(m2.group(1))
                    return 1.0 if val == 0 else round(1.0 + (val / 160.0), 2)
                except Exception:
                    return None
            return None
        else:
            return None

    def _read_freq(self):
        get = (self.cmds or {}).get("get_freq")
        if not get:
            return None
        if get.endswith(';'):
            try:
                self.session.send_ascii(get)
                raw = self.session.read_ascii_until(';', timeout=0.6) or ""
                ru = (raw or "").strip().upper()
                if not ru or ru == '?':
                    raw2 = self.session.read_ascii_until(';', timeout=0.4) or ""
                    ru = (raw2 or "").strip().upper()
                digits = ''.join(ch for ch in ru if ch.isdigit())
                if len(digits) >= 6:
                    try:
                        return int(digits)
                    except Exception:
                        return None
            except Exception:
                return None
        else:
            return None
        return None

    # --- Status/Control helpers ---
    def toggle_tuner(self, enable: bool) -> None:
        self._send("tune_on" if enable else "tune_off")

    def query_tuner_status(self) -> Tuple[Optional[bool], str]:
        key = (self.cmds or {}).get("tune_status")
        if not key: 
            return (None, "")
        if key.endswith(';'):
            self.session.send_ascii(key)
            raw = self._read_ascii_until(';', timeout=1.0)
            ru = (raw or "").upper()
            is_on = True if ("AC001" in ru or "AC002" in ru) else (False if "AC000" in ru else None)
            return (is_on, raw or "")
        else:
            return (None, "")

    def query_tx_status(self) -> Optional[bool]:
        key = (self.cmds or {}).get("get_tx")
        if not key:
            return None
        if key.endswith(';'):
            try:
                self.session.send_ascii(key)
                raw = self.session.read_ascii_until(';', timeout=0.6) or ""
                ru = (raw or "").upper()
                m = re.search(r"TX\\s*([01])", ru)
                if m:
                    return True if m.group(1) == '1' else False
            except Exception:
                return None
        return None

    def is_transmitting_hint(self) -> bool | None:
        """
        Heuristic TX detector for rigs without explicit TX status query.
        Uses SWR meter readback. Returns True/False/None.
        """
        try:
            swr = self._read_swr()
        except Exception:
            swr = None
        if swr is None:
            return None
        return True if swr > 1.02 else False

    def hard_tune(self) -> None:
        settings = self._owner_settings()
        orig_mode = self._read_mode()
        orig_power = self._read_power()
        pre_swr = self._read_swr()

        can_restore_mode = bool(orig_mode)
        set_mode_key = (self.cmds or {}).get("set_mode_restore") or (self.cmds or {}).get("set_mode") or ""
        set_power_key = (self.cmds or {}).get("set_power_restore") or (self.cmds or {}).get("set_power") or ""

        try:
            pct = int(settings.get("tune_power_pct") or settings.get("tune_power_w") or 20)
        except Exception:
            pct = 20
        pct = max(1, min(100, pct))

        changed_mode = False
        changed_power = False

        if can_restore_mode and set_mode_key and (orig_mode != "03"):
            if (self.cmds or {}).get("set_mode"):
                self._send("set_mode", mode="03")
            else:
                self._send("set_mode_restore", mode="03")
            changed_mode = True
            time.sleep(0.1)

        if set_power_key:
            if (self.cmds or {}).get("set_power"):
                self._send_power("set_power", pct)
            else:
                self._send_power("set_power_restore", pct)
            changed_power = True
            time.sleep(0.1)

        if (self.cmds or {}).get("tx_on"):
            self._send("tx_on"); time.sleep(0.2)
        if (self.cmds or {}).get("hard_tune"):
            self._send("hard_tune")
        else:
            self.session.send_ascii("AC002;")

        start_ts = time.time()
        while (time.time() - start_ts) < 10.0:
            if (self.cmds or {}).get("tune_status"):
                self._send("tune_status"); time.sleep(0.25)
            time.sleep(0.25)

        if (self.cmds or {}).get("tx_off"):
            self._send("tx_off")
        try:
            self.session.send_ascii("TX0;")
        except Exception:
            pass

        post_swr = self._read_swr()

        if changed_mode and orig_mode and set_mode_key:
            if (self.cmds or {}).get("set_mode"):
                self._send("set_mode", mode=orig_mode)
            else:
                self._send("set_mode_restore", mode=orig_mode)
            time.sleep(0.05)

        if changed_power and (orig_power is not None) and set_power_key:
            if (self.cmds or {}).get("set_power"):
                self._send_power("set_power", int(orig_power))
            else:
                self._send_power("set_power_restore", int(orig_power))

        try:
            owner = getattr(self.session, "owner", None)
            if owner and hasattr(owner, "_log"):
                owner._log(f"[SWR] before={pre_swr} after={post_swr} (approx; see '[SWR meter raw]' if present)")
        except Exception:
            pass

    # Public wrappers for UI
    def get_mode(self): return self._read_mode()
    def get_power(self): return self._read_power()
    def get_swr(self): return self._read_swr()
    def get_frequency(self): return self._read_freq()
    def set_mode(self, md_hex: str):
        if (self.cmds or {}).get('set_mode'): self._send('set_mode', mode=md_hex)
        else: self._send('set_mode_restore', mode=md_hex)
    def set_power_pct(self, pct: int):
        pct = max(1, min(100, int(pct)))
        if (self.cmds or {}).get('set_power'): self._send_power('set_power', pct)
        else: self._send_power('set_power_restore', pct)
    def start_hard_tune(self):
        if (self.cmds or {}).get('hard_tune'): self._send('hard_tune')
        else: self.session.send_ascii('AC002;')
    def tx_on(self): self._send('tx_on')
    def tx_off(self): self._send('tx_off')
    def tune_off(self): self._send('tune_off')
    def poll_tuner_status_once(self):
        if (self.cmds or {}).get('tune_status'): self._send('tune_status')
